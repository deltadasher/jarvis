import bpy, math, os, random
from mathutils import Vector
from math import sin,cos,pi
ROOT=os.path.dirname(os.path.abspath(__file__))
os.makedirs(ROOT,exist_ok=True)
bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
for d in bpy.data.materials: bpy.data.materials.remove(d)
scene=bpy.context.scene
col=bpy.data.collections.new('NERIS | EXPORT'); scene.collection.children.link(col)
studio=bpy.data.collections.new('STUDIO | DO NOT EXPORT');scene.collection.children.link(studio)
# One transportable color atlas and packed ORM, with deliberate hand-designed color families.
palette=[('Brushed Moon Silver',(.65,.79,.84),.92,.27),('Tidal Platinum',(.85,.93,.94),.87,.20),('Pearl Ivory',(.85,.96,.92),.12,.22),('Abyss Leather',(.015,.065,.095),.05,.58),('Ocean Sapphire',(.028,.30,.48),.32,.16),('Deep Engraved Recess',(.007,.035,.056),.3,.34),('Seafoam Glass',(.12,.71,.80),.22,.17),('Pearl Highlight',(.66,.90,.94),.12,.16)]
N=1024
base=bpy.data.images.new('Neris_BaseColor',width=N,height=N,alpha=True)
orm=bpy.data.images.new('Neris_ORM',width=N,height=N,alpha=True)
normal=bpy.data.images.new('Neris_Normal',width=N,height=N,alpha=True)
pix=[]; opix=[];npix=[]
random.seed(12)
for y in range(N):
 for x in range(N):
  k=(x//256)+4*(y//512); name,c,m,r=palette[k]
  grain=(random.random()-.5)*.025
  # Directional fine brushed metal and leather texture; restrained so edges carry the form.
  v=grain + (.009*sin(y*.85) if m>.7 else .006*sin(x*.9)*sin(y*.72))
  pix.extend([max(0,min(1,q+v)) for q in c]+[1]);opix.extend([1,r,m,1]);npix.extend([.5,.5,1,1])
for im,p,name in [(base,pix,'Neris_BaseColor.png'),(orm,opix,'Neris_ORM.png'),(normal,npix,'Neris_Normal.png')]:
 
 if im != base:im.colorspace_settings.name='Non-Color'
 im.pixels=p; im.filepath_raw=os.path.join(ROOT,name);im.file_format='PNG';im.save()
orm.colorspace_settings.name='Non-Color';normal.colorspace_settings.name='Non-Color'
mats=[]
for k,(name,c,m,r) in enumerate(palette):
 mat=bpy.data.materials.new(name); mat.diffuse_color=(*c,1);mat.use_nodes=True
 n=mat.node_tree.nodes; l=mat.node_tree.links; bs=n.get('Principled BSDF');tex=n.new('ShaderNodeTexImage');tex.image=base
 l.new(tex.outputs['Color'],bs.inputs['Base Color']);bs.inputs['Metallic'].default_value=m;bs.inputs['Roughness'].default_value=r
 # Add ORM mapping so GLB exports metallic/roughness texture data.
 packed=n.new('ShaderNodeTexImage');packed.image=orm;sep=n.new('ShaderNodeSeparateColor');l.new(packed.outputs['Color'],sep.inputs[0]);l.new(sep.outputs['Green'],bs.inputs['Roughness']);l.new(sep.outputs['Blue'],bs.inputs['Metallic'])
 if False:
  l.new(tex.outputs['Color'],bs.inputs['Emission Color']);bs.inputs['Emission Strength'].default_value=.6 if k==4 else 1.6
 mats.append(mat)
parts=[]
def finish(obj,name,mi=0,bev=0):
 obj.name=name
 for c in list(obj.users_collection): c.objects.unlink(obj)
 col.objects.link(obj);obj.data.materials.clear();obj.data.materials.append(mats[mi]);parts.append(obj)
 if bev:
  mod=obj.modifiers.new('Machined light-catching edges','BEVEL');mod.width=bev;mod.segments=2
  bpy.context.view_layer.objects.active=obj;bpy.ops.object.modifier_apply(modifier=mod.name)
 # Flat faces keep precision-cut planes; bevels provide the specular transitions.
 return obj

def poly(name,coords,thick,mi=0,bev=.012,y=0):
 # Front contour viewed along Y, extruded for a genuine closed mesh.
 n=len(coords);v=[(x,y-thick/2,z) for x,z in coords]+[(x,y+thick/2,z) for x,z in coords]
 f=[tuple(range(n-1,-1,-1)),tuple(range(n,n*2))]+[(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)]
 me=bpy.data.meshes.new(name);me.from_pydata(v,[],f);me.update();ob=bpy.data.objects.new(name,me);col.objects.link(ob);return finish(ob,name,mi,bev)
def path(name,points,r=.018,mi=1,sides=6):
 # Tubular filigree follows intentional traced architectural paths.
 cu=bpy.data.curves.new(name,'CURVE');cu.dimensions='3D';cu.resolution_u=1;cu.bevel_depth=r;cu.use_fill_caps=True;cu.bevel_resolution=0;cu.resolution_u=1
 closed=(Vector(points[0])-Vector(points[-1])).length<1e-6
 if closed:points=points[:-1]
 sp=cu.splines.new('POLY');sp.points.add(len(points)-1);sp.use_cyclic_u=closed
 for p,co in zip(sp.points,points):p.co=(*co,1)
 ob=bpy.data.objects.new(name,cu);col.objects.link(ob);bpy.context.view_layer.objects.active=ob;ob.select_set(True);bpy.ops.object.convert(target='MESH');ob.select_set(False);return finish(ob,name,mi)
def cyl(name,z,rad,depth,mi=1,verts=12):
 bpy.ops.mesh.primitive_cylinder_add(vertices=verts,radius=rad,depth=depth,location=(0,0,z));return finish(bpy.context.object,name,mi,.014)
def gem(name,x,z,w,h,mi=4,y=-.1):
 # Faceted, double-pyramid crystal with strong diamond silhouette.
 vs=[(x-w,y,z),(x,y,z+h),(x+w,y,z),(x,y,z-h),(x,y-.14,z),(x,y+.1,z)]
 fs=[(0,1,4),(1,2,4),(2,3,4),(3,0,4),(1,0,5),(2,1,5),(3,2,5),(0,3,5)]
 me=bpy.data.meshes.new(name);me.from_pydata(vs,[],fs);ob=bpy.data.objects.new(name,me);col.objects.link(ob);return finish(ob,name,mi)

# NERIS: an asymmetrical, curling wave saber. All contours are geometry.
def sweep(name, stations, mi=0):
 # Stations (x,z,half-width,depth), local tangent normal in XZ.
 vs=[]; fs=[]
 for i,(x,z,w,d) in enumerate(stations):
  lo=stations[max(0,i-1)];hi=stations[min(len(stations)-1,i+1)]
  dx=hi[0]-lo[0];dz=hi[1]-lo[1];L=math.hypot(dx,dz);nx=dz/L;nz=-dx/L
  for a,b in [(0,-1),(.76,-.45),(1,0),(.76,.45),(0,1),(-.76,.45),(-1,0),(-.76,-.45)]:
   vs.append((x+nx*a*w,b*d,z+nz*a*w))
 fs.append(tuple(range(7,-1,-1)))
 for i in range(len(stations)-1):
  for k in range(8):fs.append((8*i+k,8*i+(k+1)%8,8*(i+1)+(k+1)%8,8*(i+1)+k))
 fs.append(tuple(range((len(stations)-1)*8,len(stations)*8)))
 me=bpy.data.meshes.new(name);me.from_pydata(vs,[],fs);me.update();ob=bpy.data.objects.new(name,me);col.objects.link(ob);finish(ob,name,mi)
 for p in me.polygons:p.use_smooth=True
 for e in me.edges:
  if e.vertices[0]%8==e.vertices[1]%8:e.use_edge_sharp=True
 return ob

def pearl(name,loc,rad,mi=2):
 bpy.ops.mesh.primitive_uv_sphere_add(segments=24,ring_count=12,radius=rad,location=loc)
 ob=finish(bpy.context.object,name,mi)
 for p in ob.data.polygons:p.use_smooth=True
 return ob

def arc(cx,cz,rx,rz,a0,a1,n=64,width=.12,depth=.10):
 return [(cx+rx*cos(t),cz+rz*sin(t),max(.009,width*sin(pi*i/n)**.65),depth*(.45+.55*sin(pi*i/n))) for i in range(n+1) for t in [a0+(a1-a0)*i/n]]
# Raised ridge flowing from the curl into a narrow breaking-wave tip.
def center(t):return -.12+.30*sin(pi*t*.86)+.61*t**4
stations=[]
for i in range(81):
 t=i/80;z=1.28+6.0*t
 w=(.24+.10*sin(pi*t)+.045*sin(2*pi*t))*max(.012,(1-t**5))*(.28+.72*min(1,t/.13))
 stations.append((center(t),z,max(.003,w),.135*min(1,w/.16)))
sweep('Long breaking-wave silver forging',stations)
# A real, open curl at blade heel. Two intertwined streams leave negative space.
sweep('Blade heel curling breaker',arc(-.32,1.60,.69,.68,-.20,4.15,72,.16,.125),0)
sweep('Heel return rivulet',arc(-.33,1.65,.43,.41,.25,4.55,58,.073,.145),6)
# Recessed blue-lens ribbon follows the length; split silver channels along its margins.
for sy in [-1,1]:
 # Broad, curved opaque glass-look insert built as a shallow closed volume.
 left=[];right=[]
 for j in range(57):
  t=.065+.89*j/56;z=1.28+6*t;x=center(t)
  wid=.105*sin(pi*j/56)**.65+.003
  left.append((x-.035-wid,z));right.append((x-.035+wid,z))
 poly('Sapphire tide lens',left+right[::-1],.025,4,.004,y=sy*.136)
 for s in [-1,1]:
  pts=[]
  for j in range(62):
   t=.07+.88*j/61;z=1.28+6*t;x=center(t);w=.115*sin(pi*j/61)**.65+.01
   pts.append((x-.035+s*w,sy*.157,z))
  path('Silver lens lip',pts,.009,1)
 # Central bright liquid filament and discontinuous fine caustic chevrons.
 path('Seafoam vein',[(center(t)-.05+ .018*sin(t*18),sy*.158,1.28+6*t) for t in [.08+.83*j/70 for j in range(71)]],.012,6)
 for z in [2.28,2.98,3.70,4.44,5.17,5.85]:
  t=(z-1.28)/6;x=center(t)
  path('Ripple-cut micro engraving',[(x-.10,sy*.164,z-.085),(x-.005,sy*.17,z),(x+.03,sy*.166,z+.14)],.009,7)
 # Delicate scroll chased into broad heel.
 pts=[(-.32+.58*cos(t),sy*.155,1.6+.57*sin(t)) for t in [0.4+j*3.4/50 for j in range(51)]]
 path('Heel curl chase',pts,.014,1)
# Asymmetric tidal crescent guard around an actual pearl. Distinct from wing guards.
sweep('Deep crescent guard body',arc(.00,.49,1.18,.80,2.84,6.48,88,.165,.17),0)
sweep('Rising left tide quillon',arc(-.29,.76,1.13,.55,2.25,4.74,62,.115,.14),0)
for sy in [-1,1]:
 path('Crescent sapphire chased channel',[(1.17*cos(t),sy*.162,.49+.80*sin(t)) for t in [2.95+j*3.34/78 for j in range(79)]],.032,4)
 path('Crescent platinum fine lip',[(1.22*cos(t),sy*.17,.49+.86*sin(t)) for t in [3.07+j*3.16/70 for j in range(71)]],.012,1)
 # Stylized nacre scallops, modelled as thin wire arcs.
 for j in range(11):
  t=3.33+j*.235;x=1.16*cos(t);z=.49+.79*sin(t)
  pts=[(x+.065*cos(a),sy*.181,z+.052*sin(a)) for a in [pi*.1+k*pi*.8/10 for k in range(11)]]
  path('Shellwork scallop',pts,.008,7)
# Pearl with thin interlaced orbit cradle and three authentic mounting claws.
pearl('Heart of the tide',(.03,0,.48),.28,2)
for j in range(3):
 a=j*2*pi/3+pi/6
 path('Pearl cradle claw',[(.03+.34*cos(a),0,.48+.34*sin(a)),(.03+.27*cos(a),-.15,.48+.27*sin(a)),(.03+.20*cos(a),-.22,.48+.20*sin(a))],.024,1)
for sy in [-1,1]:
 path('Pearl orbit',[(.03+.37*cos(t),sy*.08,.48+.32*sin(t)) for t in [j*2*pi/96 for j in range(97)]],.012,6)
# Connection to grip: stylized shell ferrule, blade tang structurally behind pearl.
sweep('Sculpted wave-root tang',[(.00,.58,.095,.10),(-.04,.90,.058,.08),(-.10,1.19,.077,.10),(-.07,1.55,.135,.115)],0)
poly('Nacre ferrule shell',[(-.20,-.06),(-.30,.09),(-.20,.23),(0,.31),(.20,.23),(.30,.09),(.20,-.06)],.24,0,.016)
for sy in [-1,1]:
 for x in [-.15,-.075,0,.075,.15]:
  path('Ferrule fan engraving',[(x,sy*.132,-.025),(x*.90,sy*.144,.10),(x*.4,sy*.134,.23)],.012,6)
# Restrained long oval grip with braided raised ocean hide and silver seam.
cyl('Top silver socket',-.12,.205,.15,1,20)
cyl('Dark ocean hide grip',-.88,.152,1.38,3,16)
for handed in [-1,1]:
 pts=[]
 for j in range(265):
  t=j/264;angle=handed*2*pi*7*t
  pts.append((.161*cos(angle),.161*sin(angle),-1.52+1.30*t))
 path('Crosswoven grip braid',pts,.014,6 if handed==1 else 3)
for z in [-1.62,-1.53,-.20]:cyl('Pearled grip ferrule',z,.186,.06,1,20)
for sy in [-1,1]:
 for z in [-.45,-.89,-1.32]:
  pearl('Grip nacre pin',(0,sy*.17,z),.032,2)
# Droplet pommel suspended within a carved open setting, rounded not a star.
for s in [-1,1]:
 pts=[(s*(.045+.22*sin(pi*t)**.75),0,-1.68-.76*t) for t in [j/45 for j in range(46)]]
 path('Open teardrop pommel cage',pts,.046,0)
 for sy in [-1,1]:path('Pommel edge chase',[(x,sy*.045,z) for x,y,z in pts],.012,1)
# closed faceted blue drop inside the cage
sweep('Sea drop pommel jewel',[(0,-1.79,.018,.025),(0,-1.88,.086,.10),(0,-2.03,.114,.13),(0,-2.18,.065,.085),(0,-2.31,.006,.012)],6)
cyl('Pommel crown rim',-1.68,.16,.07,1,20)
# UV atlas per material. Triplanar projection yields non-overlapping swatch families.
for ob in parts:
 me=ob.data
 uv=me.uv_layers.new(name='NerisAtlas')
 mi=palette.index(next(p for p in palette if p[0]==me.materials[0].name))
 ux=(mi%4)/4;uy=(mi//4)/2
 for face in me.polygons:
  normalvec=face.normal;axis=max(range(3),key=lambda i:abs(normalvec[i]));axes=[i for i in range(3) if i!=axis]
  for li in face.loop_indices:
   co=me.vertices[me.loops[li].vertex_index].co
   a=(co[axes[0]]*.63)%1;b=(co[axes[1]]*.41)%1
   uv.data[li].uv=(ux+.015+a*.22,uy+.015+b*.47)
# Clean each closed component independently, preserving contact boundaries.
import bmesh
for ob in parts:
 for layer in list(ob.data.uv_layers):
  if layer.name != 'NerisAtlas':ob.data.uv_layers.remove(layer)
 ob.data.uv_layers.active=ob.data.uv_layers.get('NerisAtlas')
 bm=bmesh.new();bm.from_mesh(ob.data)
 bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=.000001)
 bmesh.ops.dissolve_degenerate(bm,edges=list(bm.edges),dist=.000001)
 bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(ob.data);bm.free();ob.data.update()
# Bake object transforms, set handle-centered origin: Y front/back, Z blade-up.
bpy.ops.object.select_all(action='DESELECT')
for ob in parts: ob.select_set(True)
bpy.context.view_layer.objects.active=parts[0]
bpy.ops.object.join();weapon=bpy.context.object;weapon.name='Neris_Sword';weapon.data.name='Neris_Sword_Mesh'
scene.cursor.location=(0,0,-.87);bpy.ops.object.origin_set(type='ORIGIN_CURSOR');weapon.location=(0,0,0)
bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
# Consolidate portable shader: all metals, enamel and leather are encoded in one atlas.
weapon.name='Handle'
master=mats[0].copy();master.name='Neris_PBR_Atlas'
weapon.data.materials.clear();weapon.data.materials.append(master)
for face in weapon.data.polygons:face.material_index=0
import bmesh
bm=bmesh.new();bm.from_mesh(weapon.data)
bmesh.ops.dissolve_degenerate(bm,edges=list(bm.edges),dist=.000001)
bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(weapon.data);bm.free();weapon.data.update()
# Export-budget simplification preserves the flowing outer contour and closed shells.
dec=weapon.modifiers.new('Roblox triangle budget','DECIMATE');dec.ratio=.59
bpy.context.view_layer.objects.active=weapon;bpy.ops.object.modifier_apply(modifier=dec.name)
# Mesh custom metadata included in editable source.
weapon['Design']='NERIS • Pearl of the Undertow, curling wave saber';weapon['Pivot']='Grip center; +Z toward blade, front -Y';weapon['Roblox']='One MeshPart. Import scale as needed; use supplied PBR maps in SurfaceAppearance.'
weapon['Texture']='UV0: shared 1024px atlas. Glass-like accents are opaque PBR; no transparency required.'
scene.unit_settings.system='NONE';scene.unit_settings.scale_length=1
# Exports: only actual sword selected.
bpy.ops.export_scene.fbx(filepath=ROOT+'/Neris_Sword.fbx',use_selection=True,add_leaf_bones=False,apply_unit_scale=True,axis_forward='Z',axis_up='Y',apply_scale_options='FBX_SCALE_UNITS',bake_anim=False,path_mode='COPY',embed_textures=True,object_types={'MESH'},use_mesh_modifiers=True)
bpy.ops.export_scene.gltf(filepath=ROOT+'/Neris_Sword.glb',export_format='GLB',use_selection=True,export_yup=True,export_texcoords=True,export_normals=True,export_materials='EXPORT')
bpy.ops.wm.obj_export(filepath=ROOT+'/Neris_Sword.obj',export_selected_objects=True,export_materials=True,forward_axis='NEGATIVE_Z',up_axis='Y',path_mode='COPY')
# Readable companion maps for Roblox SurfaceAppearance.
for channel,name in [(1,'Neris_Roughness.png'),(2,'Neris_Metalness.png')]:
 im=bpy.data.images.new(name,width=N,height=N,alpha=True);ps=[]
 for i in range(N*N):v=opix[i*4+channel];ps.extend([v,v,v,1])
 im.colorspace_settings.name='Non-Color';im.pixels=ps;im.filepath_raw=ROOT+'/'+name;im.file_format='PNG';im.save();im.pack()
base.pack();orm.pack();normal.pack()
# Museum-style lighting and background, never part of the export.
def move_studio(ob):
 for c in list(ob.users_collection):c.objects.unlink(ob)
 studio.objects.link(ob)
def area(name,loc,energy,color,size,target=(0,0,2.7)):
 bpy.ops.object.light_add(type='AREA',location=loc);ob=bpy.context.object;ob.name=name;move_studio(ob);ob.data.energy=energy;ob.data.color=color;ob.data.shape='DISK';ob.data.size=size;ob.rotation_euler=(Vector(target)-ob.location).to_track_quat('-Z','Y').to_euler()
area('Key | warm softbox',(-4,-5,7),1000,(1,.87,.66),5)
area('Edge | cold strip',(3,1,6),1350,(.29,.64,1),4)
area('Fill | blue silver',(3,-5,2),650,(.52,.76,1),4)
area('Pommel kicker',(-2,-2,-1),180,(.4,.77,1),2)
world=bpy.data.worlds.new('Midnight gallery') if not bpy.data.worlds else bpy.data.worlds[0];scene.world=world;world.use_nodes=True;world.node_tree.nodes['Background'].inputs[0].default_value=(.017,.024,.041,1);world.node_tree.nodes['Background'].inputs[1].default_value=.4
bpy.ops.object.camera_add(location=(5,-28,7));cam=bpy.context.object;cam.name='CAMERA | Hero';move_studio(cam);scene.camera=cam
cam.data.type='ORTHO';cam.data.ortho_scale=10.8
cam.rotation_euler=(Vector((0,0,3.05))-cam.location).to_track_quat('-Z','Y').to_euler()
scene.render.engine='CYCLES';scene.cycles.samples=80;scene.cycles.use_denoising=False
scene.render.resolution_x=1200;scene.render.resolution_y=1800;scene.render.resolution_percentage=100
scene.view_settings.view_transform='AgX'
scene.render.image_settings.file_format='PNG';scene.render.film_transparent=False
# Compositor restrained glow only affects preview, with no promised Roblox bloom.
scene.use_nodes=True;nodes=scene.node_tree.nodes;nodes.clear();rl=nodes.new('CompositorNodeRLayers');g=nodes.new('CompositorNodeGlare');g.glare_type='FOG_GLOW';g.quality='HIGH';g.threshold=1.7;g.mix=-.92;o=nodes.new('CompositorNodeComposite');scene.node_tree.links.new(rl.outputs['Image'],g.inputs[0]);scene.node_tree.links.new(g.outputs[0],o.inputs[0])
bpy.ops.object.select_all(action='DESELECT');weapon.select_set(True);bpy.context.view_layer.objects.active=weapon
# Home view aligned to camera and saved source with image textures packed.
for screen in bpy.data.screens:
 for ar in screen.areas:
  if ar.type=='VIEW_3D':ar.spaces.active.region_3d.view_perspective='CAMERA'
scene.render.filepath=ROOT+'/Neris_Hero.png'
bpy.ops.wm.save_as_mainfile(filepath=ROOT+'/Neris_Sword.blend')
tris=sum(len(p.vertices)-2 for p in weapon.data.polygons)
with open(ROOT+'/model_stats.txt','w') as f:f.write(f'Vertices: {len(weapon.data.vertices)}\nPolygons: {len(weapon.data.polygons)}\nTriangles: {tris}\nDimensions: {tuple(weapon.dimensions)}\nMaterials: {len(weapon.data.materials)}\n')
bpy.ops.render.render(write_still=True)
cam.location=(2.3,-18,3.3);target=Vector((0,0,1.09));cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.ortho_scale=4.9
scene.render.resolution_x=1500;scene.render.resolution_y=1500;scene.render.filepath=ROOT+'/Neris_Detail.png';bpy.ops.render.render(write_still=True)
# A front orthographic view records the approved silhouette without perspective distortion.
cam.location=(0,-25,3.10);target=Vector((0,0,3.10));cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.ortho_scale=10.8
scene.render.resolution_x=1200;scene.render.resolution_y=1800;scene.render.filepath=ROOT+'/Neris_Front.png';bpy.ops.render.render(write_still=True)
print('NERIS_BUILD_COMPLETE')
