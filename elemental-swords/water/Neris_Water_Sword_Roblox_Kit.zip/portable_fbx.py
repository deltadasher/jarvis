"""Use Blender's FBX reader/writer to keep the kit's texture paths relative."""
import os
from pathlib import Path
from tempfile import TemporaryDirectory

from io_scene_fbx import data_types, encode_bin, parse_fbx


def localize_texture_paths(filename):
    path = Path(filename)
    tree, version = parse_fbx.parse(str(path))
    writers = {value: getattr(encode_bin.FBXElem, "add_" + name.lower())
               for name, value in vars(data_types).items() if isinstance(value, int)
               and hasattr(encode_bin.FBXElem, "add_" + name.lower())}

    def encode(node):
        target = encode_bin.FBXElem(node.id)
        texture_path = (node.id.lower() in {b"filename", b"relativefilename"}
                        or (node.id == b"P" and node.props[:1] == [b"Path"]))
        for index, (kind, value) in enumerate(zip(node.props_type, node.props)):
            if texture_path and kind == data_types.STRING and value.lower().endswith(b".png"):
                basename = value.replace(b"\\", b"/").rsplit(b"/", 1)[-1]
                if not (path.parent / os.fsdecode(basename)).is_file():
                    raise FileNotFoundError(os.fsdecode(basename))
                value = node.props[index] = basename
            writers[kind](target, value)
        target.elems.extend(encode(child) for child in node.elems)
        return target

    converted = encode(tree)
    with TemporaryDirectory(dir=path.parent) as temp:
        result = Path(temp) / path.name
        encode_bin.write(str(result), converted, version)
        if parse_fbx.parse(str(result)) != (tree, version):
            raise ValueError("FBX round-trip changed fields outside the texture paths.")
        result.replace(path)
