import bpy, math, os, random
from mathutils import Vector
from math import sin,cos,pi
ROOT=os.path.dirname(os.path.abspath(__file__))
os.makedirs(ROOT,exist_ok=True)
bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
for d in bpy.data.materials: bpy.data.materials.remove(d)
scene=bpy.context.scene
col=bpy.data.collections.new('VESPERMARROW | EXPORT'); scene.collection.children.link(col)
studio=bpy.data.collections.new('STUDIO | DO NOT EXPORT');scene.collection.children.link(studio)
# One transportable color atlas and packed ORM, with deliberate hand-designed color families.
palette=[('Grave iron',(.085,.105,.10),.88,.32),('Oxidized bronze',(.21,.25,.16),.72,.43),('Old ivory',(.64,.60,.43),.08,.48),('Burial linen',(.23,.225,.18),.0,.89),('Verdigris',(.12,.28,.22),.52,.62),('Deep recess',(.019,.029,.026),.2,.74),('Bone ridge',(.85,.78,.59),.02,.40),('Cold marrow',(.20,.48,.34),.05,.38)]
N=1024
base=bpy.data.images.new('Vespermarrow_BaseColor',width=N,height=N,alpha=True)
orm=bpy.data.images.new('Vespermarrow_ORM',width=N,height=N,alpha=True)
normal=bpy.data.images.new('Vespermarrow_Normal',width=N,height=N,alpha=True)
pix=[]; opix=[];npix=[]
random.seed(12)
for y in range(N):
 for x in range(N):
  k=(x//256)+4*(y//512); name,c,m,r=palette[k]
  grain=(random.random()-.5)*.025
  # Directional fine brushed metal and leather texture; restrained so edges carry the form.
  v=grain + (.009*sin(y*.85) if m>.7 else .006*sin(x*.9)*sin(y*.72))
  pix.extend([max(0,min(1,q+v)) for q in c]+[1]);opix.extend([1,r,m,1]);npix.extend([.5,.5,1,1])
for im,p,name in [(base,pix,'Vespermarrow_BaseColor.png'),(orm,opix,'Vespermarrow_ORM.png'),(normal,npix,'Vespermarrow_Normal.png')]:
 
 if im != base:im.colorspace_settings.name='Non-Color'
 im.pixels=p; im.filepath_raw=os.path.join(ROOT,name);im.file_format='PNG';im.save()
orm.colorspace_settings.name='Non-Color';normal.colorspace_settings.name='Non-Color'
mats=[]
for k,(name,c,m,r) in enumerate(palette):
 mat=bpy.data.materials.new(name); mat.diffuse_color=(*c,1);mat.use_nodes=True
 n=mat.node_tree.nodes; l=mat.node_tree.links; bs=n.get('Principled BSDF');tex=n.new('ShaderNodeTexImage');tex.image=base
 l.new(tex.outputs['Color'],bs.inputs['Base Color']);bs.inputs['Metallic'].default_value=m;bs.inputs['Roughness'].default_value=r
 # Add ORM mapping so GLB exports metallic/roughness texture data.
 packed=n.new('ShaderNodeTexImage');packed.image=orm;sep=n.new('ShaderNodeSeparateColor');l.new(packed.outputs['Color'],sep.inputs[0]);l.new(sep.outputs['Green'],bs.inputs['Roughness']);l.new(sep.outputs['Blue'],bs.inputs['Metallic'])
 if False:
  l.new(tex.outputs['Color'],bs.inputs['Emission Color']);bs.inputs['Emission Strength'].default_value=.6 if k==4 else 1.6
 mats.append(mat)
parts=[]
def finish(obj,name,mi=0,bev=0):
 obj.name=name
 for c in list(obj.users_collection): c.objects.unlink(obj)
 col.objects.link(obj);obj.data.materials.clear();obj.data.materials.append(mats[mi]);parts.append(obj)
 if bev:
  mod=obj.modifiers.new('Machined light-catching edges','BEVEL');mod.width=bev;mod.segments=2
  bpy.context.view_layer.objects.active=obj;bpy.ops.object.modifier_apply(modifier=mod.name)
 # Flat faces keep precision-cut planes; bevels provide the specular transitions.
 return obj

def poly(name,coords,thick,mi=0,bev=.012,y=0):
 # Front contour viewed along Y, extruded for a genuine closed mesh.
 n=len(coords);v=[(x,y-thick/2,z) for x,z in coords]+[(x,y+thick/2,z) for x,z in coords]
 f=[tuple(range(n-1,-1,-1)),tuple(range(n,n*2))]+[(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)]
 me=bpy.data.meshes.new(name);me.from_pydata(v,[],f);me.update();ob=bpy.data.objects.new(name,me);col.objects.link(ob);return finish(ob,name,mi,bev)
def path(name,points,r=.018,mi=1,sides=6):
 # Tubular filigree follows intentional traced architectural paths.
 cu=bpy.data.curves.new(name,'CURVE');cu.dimensions='3D';cu.resolution_u=1;cu.bevel_depth=r;cu.use_fill_caps=True;cu.bevel_resolution=0;cu.resolution_u=1
 sp=cu.splines.new('POLY');sp.points.add(len(points)-1)
 for p,co in zip(sp.points,points):p.co=(*co,1)
 ob=bpy.data.objects.new(name,cu);col.objects.link(ob);bpy.context.view_layer.objects.active=ob;ob.select_set(True);bpy.ops.object.convert(target='MESH');ob.select_set(False);return finish(ob,name,mi)
def cyl(name,z,rad,depth,mi=1,verts=12):
 bpy.ops.mesh.primitive_cylinder_add(vertices=verts,radius=rad,depth=depth,location=(0,0,z));return finish(bpy.context.object,name,mi,.014)
def gem(name,x,z,w,h,mi=4,y=-.1):
 # Faceted, double-pyramid crystal with strong diamond silhouette.
 vs=[(x-w,y,z),(x,y,z+h),(x+w,y,z),(x,y,z-h),(x,y-.14,z),(x,y+.1,z)]
 fs=[(0,1,4),(1,2,4),(2,3,4),(3,0,4),(1,0,5),(2,1,5),(3,2,5),(0,3,5)]
 me=bpy.data.meshes.new(name);me.from_pydata(vs,[],fs);ob=bpy.data.objects.new(name,me);col.objects.link(ob);return finish(ob,name,mi)

# Deliberately asymmetrical reliquary silhouette, drawn independently of Genesis.
def spine(z):return -.08+.18*sin((z-.8)*.77)
def width(z):return .34+.10*sin((z-.9)*.6)
# Raised broad forging, lenticular edge sections. Hollow crown is built as two closed prongs.
def strip(name,rows,mi=0):
 vs=[]
 for x,z,w,d in rows:
  vs += [(x-w,0,z),(x-.70*w,-d*.60,z),(x,-d,z),(x+.7*w,-d*.6,z),(x+w,0,z),(x+.7*w,d*.6,z),(x,d,z),(x-.7*w,d*.6,z)]
 fs=[tuple(range(7,-1,-1))]
 for j in range(len(rows)-1):
  for k in range(8):fs.append((j*8+k,j*8+(k+1)%8,(j+1)*8+(k+1)%8,(j+1)*8+k))
 fs.append(tuple(range((len(rows)-1)*8,len(rows)*8)))
 me=bpy.data.meshes.new(name);me.from_pydata(vs,[],fs);me.update();ob=bpy.data.objects.new(name,me);col.objects.link(ob);finish(ob,name,mi)
 return ob
rows=[]
for i in range(43):
 z=.82+i*4.83/42;rows.append((spine(z),z,width(z),.13))
strip('Blackened iron | swept cutting body',rows)
# Asymmetric tear-shaped absence: open all the way through. No transparent decal.
poly('Hollow crown | outer iron edge',[(spine(5.52)-.36,5.52),(-.39,6.08),(-.33,6.67),(-.14,7.25),(.11,7.82),(.12,7.35),(.015,6.87),(-.03,6.34),(.03,5.88),(.19,5.60)],.19,0,.008)
poly('Hollow crown | hooked cutting prong',[(.19,5.48),(.36,5.73),(.44,6.14),(.37,6.55),(.23,6.96),(.11,7.82),(.06,7.04),(.18,6.51),(.24,6.14),(.18,5.88),(-.01,5.64)],.15,0,.009)
# Bright cutting bevel traces only the external forward side, not a decorative frame.
for sy in [-1,1]:
 pts=[]
 for i in range(43):
  z=.91+i*4.65/42;pts.append((spine(z)+width(z)*.83,sy*.057,z))
 path('Polished working edge',pts,.019,1)
# Backbone is curved and slightly off center; plates articulated instead of continuous ornament.
for sy in [-1,1]:
 path('Continuous curved bone keel',[(spine(.98+i*5.02/36)-.095,sy*.148,.98+i*5.02/36) for i in range(37)],.064,6)
for i in range(12):
 z=1.08+i*.39;x=spine(z)-.06;w=width(z)*.81
 # overlapping scapular plates, alternating skew to avoid mechanical symmetry
 outline=[(x-w*.89,z+.11),(x-w*.64,z+.34),(x-.055,z+.39),(x+w*.69,z+.24),(x+w*.92,z-.025),(x+.02,z+.075),(x-w*.35,z-.04)]
 for sy in [-1,1]:
  poly('Vertebra %02d | ivory shield'%i,outline,.063,2,.020,y=sy*.14)
  path('Vertebral raised ridge',[(x-w*.76,sy*.195,z+.17),(x-.03,sy*.225,z+.25),(x+w*.68,sy*.19,z+.12)],.021,6)
  # dark branching fissure laid into the bone face as narrow geometric inlay
  if i%2==0:
   path('Age fissure',[(x-w*.49,sy*.178,z+.26),(x-w*.18,sy*.18,z+.19),(x-w*.28,sy*.18,z+.10)],.0055,5)
# Pale crown spine creates a hollow broken relic at tip, tapering rather than a skull.
poly('Crown | bone finger',[(-.32,5.52),(-.41,5.96),(-.35,6.52),(-.21,7.03),(.10,7.76),(-.04,6.95),(-.19,6.45),(-.25,5.96),(-.10,5.59)],.10,6,.012,y=-.093)
poly('Crown | back bone finger',[(-.32,5.52),(-.41,5.96),(-.35,6.52),(-.21,7.03),(.10,7.76),(-.04,6.95),(-.19,6.45),(-.25,5.96),(-.10,5.59)],.10,2,.012,y=.093)
# Rib cage guard. Tapered elliptical swept ribs are true capped shells.
def bone(name,points,radii,mi=2):
 vs=[];n=8
 for i,(x,y,z) in enumerate(points):
  tangent=Vector(points[min(i+1,len(points)-1)])-Vector(points[max(i-1,0)]);tangent.normalize()
  side=Vector((0,1,0));other=tangent.cross(side).normalized()
  for j in range(n):
   a=2*pi*j/n;p=Vector((x,y,z))+side*cos(a)*radii[i]*.69+other*sin(a)*radii[i];vs.append(tuple(p))
 fs=[tuple(range(n-1,-1,-1))]
 for i in range(len(points)-1):
  for j in range(n):fs.append((i*n+j,i*n+(j+1)%n,(i+1)*n+(j+1)%n,(i+1)*n+j))
 fs.append(tuple(range((len(points)-1)*n,len(points)*n)))
 me=bpy.data.meshes.new(name);me.from_pydata(vs,[],fs);me.update();ob=bpy.data.objects.new(name,me);col.objects.link(ob);finish(ob,name,mi)
 for p in me.polygons:p.use_smooth=True
for s in [-1,1]:
 for j in range(3):
  coords=[(.12,.92-j*.27),(.39,.91-j*.33),(.70,1.01-j*.38),(1.02,1.24-j*.41),(1.25,1.48-j*.43),(1.43,1.80-j*.45)]
  points=[(s*x,0,z) for x,z in coords]
  bone('Swept rib %d %d'%(s,j),points,[.12,.092,.073,.058,.038,.009],2 if j!=1 else 6)
  # Fine marrow canal and transverse sutures reinforce anatomy.
  path('Rib canal',[(s*x,-.082,z+.018) for x,z in coords[:-1]],.013,1)
  for k in [1,3]:
   x,z=coords[k];path('Rib joint',[(s*(x-.045),-.084,z+.044),(s*(x+.034),-.087,z-.039)],.011,1)
# narrow sternum, no jewel or icon replacing the structural anatomy
poly('Sternum | dark socket',[(-.22,.0),(-.31,.49),(-.22,1.04),(0,1.37),(.22,1.04),(.31,.49),(.22,.0)],.30,0,.025)
for sy in [-1,1]:
 poly('Sternum | bone breastplate',[(-.14,.16),(-.21,.50),(-.14,.97),(0,1.25),(.14,.97),(.21,.50),(.14,.16)],.055,2,.02,y=sy*.18)
 path('Sternum suture',[(0,sy*.215,.27),(-.018,sy*.215,.50),(.018,sy*.215,.69),(0,sy*.215,1.10)],.017,5)
 for z in [.4,.58,.77]:
  path('Ancient bronze staple',[(-.060,sy*.234,z+.014),(-.045,sy*.252,z),(.054,sy*.252,z),(.062,sy*.23,z-.02)],.012,1)
# Burial cloth wrap: layered broad helices with worn seams, irregular knot and loose hem.
cyl('Black wood grip',-.66,.157,1.38,5,12)
for i in range(8):
 z=-1.29+i*.159
 vs=[];pts=[]
 for j in range(33):
  t=j/32*2*pi;r=.169+.009*sin(t*3+i*.85);zz=z+j/32*.159+.013*sin(t*2+i)
  half=.098+.009*sin(t*3+i);pts.append(((r+.017)*cos(t),(r+.017)*sin(t),zz+half))
  for dr,dz in [(-.006,-half),(.016,-half),(.016,half),(-.006,half)]:vs.append(((r+dr)*cos(t),(r+dr)*sin(t),zz+dz))
 fs=[(3,2,1,0)]
 for j in range(32):
  for k in range(4):fs.append((j*4+k,j*4+(k+1)%4,(j+1)*4+(k+1)%4,(j+1)*4+k))
 fs.append((128,129,130,131))
 me=bpy.data.meshes.new('Linen band');me.from_pydata(vs,[],fs);me.update();ob=bpy.data.objects.new('Burial linen | irregular overlapping band',me);col.objects.link(ob);finish(ob,ob.name,3)
 path('Linen band | worn pale selvage',pts,.006,2)
# a wide fold crosses the front of the winding, like a tucked strip of cloth
poly('Linen | tucked diagonal fold',[(-.16,-.29),(.15,-.43),(.17,-.62),(-.16,-.43)],.026,3,.008,y=-.18)
for z in [-1.39,-.01]:
 cyl('Oxidized iron ferrule',z,.192,.12,0,12)
 for dz in [-.044,.044]:cyl('Ferrule bronze lip',z+dz,.198,.014,1,12)
poly('Burial cloth | torn trailing end',[(.12,-1.03),(.26,-1.18),(.37,-1.64),(.30,-1.78),(.27,-1.65),(.20,-1.83),(.20,-1.54),(.12,-1.23)],.035,3,.007,y=.04)
# Terminal sacrum with empty elongated aperture, borrowing anatomy not celestial forms.
for s in [-1,1]:
 bone('Sacral pommel',[(s*.11,0,-1.43),(s*.24,0,-1.63),(s*.22,0,-1.91),(s*.085,0,-2.10),(0,0,-2.18)],[.11,.105,.09,.065,.025],2)
 poly('Pommel ossified spur',[(s*.18,-1.57),(s*.34,-1.64),(s*.29,-1.87),(s*.20,-1.92)],.14,6,.008)
path('Pommel marrow remnant',[(0,0,-1.48),(.045,0,-1.74),(0,0,-1.91)],.025,7)
# UV atlas per material. Triplanar projection yields non-overlapping swatch families.
for ob in parts:
 group=ob.vertex_groups.new(name=ob.name);group.add(list(range(len(ob.data.vertices))),1.0,'REPLACE')
 me=ob.data
 uv=me.uv_layers.new(name='VespermarrowAtlas')
 mi=palette.index(next(p for p in palette if p[0]==me.materials[0].name))
 ux=(mi%4)/4;uy=(mi//4)/2
 for face in me.polygons:
  normalvec=face.normal;axis=max(range(3),key=lambda i:abs(normalvec[i]));axes=[i for i in range(3) if i!=axis]
  for li in face.loop_indices:
   co=me.vertices[me.loops[li].vertex_index].co
   a=(co[axes[0]]*.63)%1;b=(co[axes[1]]*.41)%1
   uv.data[li].uv=(ux+.015+a*.22,uy+.015+b*.47)
# Clean each closed component independently, preserving contact boundaries.
import bmesh
for ob in parts:
 for layer in list(ob.data.uv_layers):
  if layer.name != 'VespermarrowAtlas':ob.data.uv_layers.remove(layer)
 ob.data.uv_layers.active=ob.data.uv_layers.get('VespermarrowAtlas')
 bm=bmesh.new();bm.from_mesh(ob.data)
 bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=.000001)
 bmesh.ops.dissolve_degenerate(bm,edges=list(bm.edges),dist=.000001)
 bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(ob.data);bm.free();ob.data.update()
# Bake object transforms, set handle-centered origin: Y front/back, Z blade-up.
bpy.ops.object.select_all(action='DESELECT')
for ob in parts: ob.select_set(True)
bpy.context.view_layer.objects.active=parts[0]
bpy.ops.object.join();weapon=bpy.context.object;weapon.name='Vespermarrow_Sword';weapon.data.name='Vespermarrow_Sword_Mesh'
scene.cursor.location=(0,0,-.66);bpy.ops.object.origin_set(type='ORIGIN_CURSOR');weapon.location=(0,0,0)
bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
# Consolidate portable shader: all metals, enamel and leather are encoded in one atlas.
weapon.name='Handle'
master=mats[0].copy();master.name='Vespermarrow_PBR_Atlas'
weapon.data.materials.clear();weapon.data.materials.append(master)
for face in weapon.data.polygons:face.material_index=0
import bmesh
bm=bmesh.new();bm.from_mesh(weapon.data)
bmesh.ops.dissolve_degenerate(bm,edges=list(bm.edges),dist=.000001)
bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(weapon.data);bm.free();weapon.data.update()
# Mesh custom metadata included in editable source.
weapon['Design']='VESPERMARROW | The Hollow Vigil. Articulated bone and burial iron; empty crown.';weapon['Pivot']='Grip center; +Z toward blade, front -Y';weapon['Roblox']='One MeshPart. Import scale as needed; use supplied PBR maps in SurfaceAppearance.'
weapon['Texture']='UV0: shared 1024px tiled palette atlas. No emissive glow required.'
scene.unit_settings.system='NONE';scene.unit_settings.scale_length=1
# Exports: only actual sword selected.
bpy.ops.export_scene.fbx(filepath=ROOT+'/Vespermarrow_Sword.fbx',use_selection=True,add_leaf_bones=False,apply_unit_scale=True,axis_forward='Z',axis_up='Y',apply_scale_options='FBX_SCALE_UNITS',bake_anim=False,path_mode='COPY',embed_textures=True,object_types={'MESH'},use_mesh_modifiers=True)
bpy.ops.export_scene.gltf(filepath=ROOT+'/Vespermarrow_Sword.glb',export_format='GLB',use_selection=True,export_yup=True,export_texcoords=True,export_normals=True,export_materials='EXPORT')
bpy.ops.wm.obj_export(filepath=ROOT+'/Vespermarrow_Sword.obj',export_selected_objects=True,export_materials=True,forward_axis='NEGATIVE_Z',up_axis='Y',path_mode='COPY')
# Readable companion maps for Roblox SurfaceAppearance.
for channel,name in [(1,'Vespermarrow_Roughness.png'),(2,'Vespermarrow_Metalness.png')]:
 im=bpy.data.images.new(name,width=N,height=N,alpha=True);ps=[]
 for i in range(N*N):v=opix[i*4+channel];ps.extend([v,v,v,1])
 im.colorspace_settings.name='Non-Color';im.pixels=ps;im.filepath_raw=ROOT+'/'+name;im.file_format='PNG';im.save();im.pack()
base.pack();orm.pack();normal.pack()
# Museum-style lighting and background, never part of the export.
def move_studio(ob):
 for c in list(ob.users_collection):c.objects.unlink(ob)
 studio.objects.link(ob)
def area(name,loc,energy,color,size,target=(0,0,2.7)):
 bpy.ops.object.light_add(type='AREA',location=loc);ob=bpy.context.object;ob.name=name;move_studio(ob);ob.data.energy=energy;ob.data.color=color;ob.data.shape='DISK';ob.data.size=size;ob.rotation_euler=(Vector(target)-ob.location).to_track_quat('-Z','Y').to_euler()
area('Key | warm softbox',(-4,-5,7),1000,(1,.91,.78),5)
area('Edge | cold strip',(3,1,6),1350,(.44,.72,.64),4)
area('Fill | blue silver',(3,-5,2),650,(.63,.72,.72),4)
area('Pommel kicker',(-2,-2,-1),180,(.4,.77,1),2)
world=bpy.data.worlds.new('Midnight gallery') if not bpy.data.worlds else bpy.data.worlds[0];scene.world=world;world.use_nodes=True;world.node_tree.nodes['Background'].inputs[0].default_value=(.017,.024,.041,1);world.node_tree.nodes['Background'].inputs[1].default_value=.4
bpy.ops.object.camera_add(location=(5,-28,7));cam=bpy.context.object;cam.name='CAMERA | Hero';move_studio(cam);scene.camera=cam
cam.data.type='ORTHO';cam.data.ortho_scale=11.5
cam.rotation_euler=(Vector((0,0,3.45))-cam.location).to_track_quat('-Z','Y').to_euler()
scene.render.engine='CYCLES';scene.cycles.samples=96;scene.cycles.use_denoising=False
scene.render.resolution_x=1400;scene.render.resolution_y=1800;scene.render.resolution_percentage=100
scene.view_settings.view_transform='AgX'
scene.render.image_settings.file_format='PNG';scene.render.film_transparent=False
# Compositor restrained glow only affects preview, with no promised Roblox bloom.
scene.use_nodes=True;nodes=scene.node_tree.nodes;nodes.clear();rl=nodes.new('CompositorNodeRLayers');g=nodes.new('CompositorNodeGlare');g.glare_type='FOG_GLOW';g.quality='HIGH';g.threshold=1.7;g.mix=-.92;o=nodes.new('CompositorNodeComposite');scene.node_tree.links.new(rl.outputs['Image'],g.inputs[0]);scene.node_tree.links.new(g.outputs[0],o.inputs[0])
bpy.ops.object.select_all(action='DESELECT');weapon.select_set(True);bpy.context.view_layer.objects.active=weapon
# Home view aligned to camera and saved source with image textures packed.
for screen in bpy.data.screens:
 for ar in screen.areas:
  if ar.type=='VIEW_3D':ar.spaces.active.region_3d.view_perspective='CAMERA'
scene.render.filepath=ROOT+'/Vespermarrow_Hero.png'
bpy.ops.wm.save_as_mainfile(filepath=ROOT+'/Vespermarrow_Sword.blend')
tris=sum(len(p.vertices)-2 for p in weapon.data.polygons)
with open(ROOT+'/model_stats.txt','w') as f:f.write(f'Vertices: {len(weapon.data.vertices)}\nPolygons: {len(weapon.data.polygons)}\nTriangles: {tris}\nDimensions: {tuple(weapon.dimensions)}\nMaterials: {len(weapon.data.materials)}\n')
bpy.ops.render.render(write_still=True)
cam.location=(2.4,-16,4.1);target=Vector((0,0,1.09));cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.ortho_scale=4.9
scene.render.resolution_x=1600;scene.render.resolution_y=1400;scene.render.filepath=ROOT+'/Vespermarrow_Detail.png';bpy.ops.render.render(write_still=True)
# A front orthographic view records the approved silhouette without perspective distortion.
cam.location=(0,-25,3.45);target=Vector((0,0,3.45));cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.ortho_scale=11.5
scene.render.resolution_x=1200;scene.render.resolution_y=1800;scene.render.filepath=ROOT+'/Vespermarrow_Front.png';bpy.ops.render.render(write_still=True)
print('VESPERMARROW_BUILD_COMPLETE')
