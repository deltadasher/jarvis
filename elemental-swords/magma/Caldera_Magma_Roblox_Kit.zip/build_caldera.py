import bpy, math, os, random, bmesh, json
from mathutils import Vector
from math import sin, cos, pi
ROOT=os.path.dirname(os.path.abspath(__file__));random.seed(741)
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
scene=bpy.context.scene
col=bpy.data.collections.new('CALDERA | EXPORT');scene.collection.children.link(col)
studio=bpy.data.collections.new('STUDIO | DO NOT EXPORT');scene.collection.children.link(studio)
palette=[('Obsidian',(.045,.052,.064),.48,.29),('Basalt',(.09,.08,.075),.12,.7),('Glass edge',(.16,.19,.22),.7,.21),('Heat copper',(.56,.23,.075),.78,.36),('Ash leather',(.048,.033,.025),.04,.72),('Lava',(.98,.09,.003),.06,.32),('Hot core',(1,.56,.045),.03,.29),('Scorched copper',(.20,.09,.047),.68,.51)]
N=1024
import numpy as np
rng=np.random.default_rng(741)
y,x=np.mgrid[0:N,0:N];noise=rng.random((N,N))-.5
maps={k:np.ones((N,N,4),dtype=np.float32) for k in ['BaseColor','ORM','Normal','Emission']}
for k,(name,c,m,r) in enumerate(palette):
 mask=(x//256+4*(y//512))==k
 grain=noise*.04+.016*np.sin(x*.24)*np.sin(y*.18)+.01*np.sin(x*.055+y*.071)
 for ch in range(3):maps['BaseColor'][:,:,ch][mask]=np.clip(c[ch]+grain[mask],0,1)
 maps['ORM'][:,:,1][mask]=np.clip(r+noise[mask]*.065,0,1);maps['ORM'][:,:,2][mask]=m
 maps['Normal'][:,:,0][mask]=.5+noise[mask]*(.10 if k in [1,4] else .025);maps['Normal'][:,:,1][mask]=.5+np.sin(x[mask]*.5)*(.03 if k==4 else .008);maps['Normal'][:,:,2][mask]=1
 for ch in range(3):maps['Emission'][:,:,ch][mask]=c[ch] if k in [5,6] else 0
ims={}
for typ,arr in maps.items():
 im=bpy.data.images.new('Caldera_'+typ,width=N,height=N,alpha=True)
 if typ in ['ORM','Normal']:im.colorspace_settings.name='Non-Color'
 im.pixels.foreach_set(arr.ravel());im.filepath_raw=ROOT+'/Caldera_'+typ+'.png';im.file_format='PNG';im.save();ims[typ]=im
mats=[]
for name,c,m,r in palette:
 mat=bpy.data.materials.new(name);mat.diffuse_color=(*c,1);mats.append(mat)
parts=[]
def finish(ob,name,mi=0,bev=0):
 ob.name=name
 for c in list(ob.users_collection):c.objects.unlink(ob)
 col.objects.link(ob);ob.data.materials.clear();ob.data.materials.append(mats[mi]);ob['atlas']=mi;parts.append(ob)
 if bev:
  bm=bmesh.new();bm.from_mesh(ob.data);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(ob.data);bm.free()
  bpy.context.view_layer.objects.active=ob;mod=ob.modifiers.new('Forged edge bevel','BEVEL');mod.width=bev;mod.segments=2;bpy.ops.object.modifier_apply(modifier=mod.name)
 return ob

def poly(name,coords,thick,mi=0,bev=.008,y=0,facet=False):
 n=len(coords);v=[(x,y-thick/2,z) for x,z in coords]+[(x,y+thick/2,z) for x,z in coords]
 if facet:
  cx=sum(p[0] for p in coords)/n;cz=sum(p[1] for p in coords)/n
  v += [(cx,y-thick*.68,cz),(cx,y+thick*.68,cz)]
  f=[((i+1)%n,i,2*n) for i in range(n)]+[(n+i,n+(i+1)%n,2*n+1) for i in range(n)]
 else:f=[tuple(range(n-1,-1,-1)),tuple(range(n,n*2))]
 f += [(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)]
 me=bpy.data.meshes.new(name);me.from_pydata(v,[],f);me.update();ob=bpy.data.objects.new(name,me);col.objects.link(ob);return finish(ob,name,mi,bev)
def path(name,points,r=.015,mi=3):
 cu=bpy.data.curves.new(name,'CURVE');cu.dimensions='3D';cu.resolution_u=1;cu.bevel_depth=r;cu.use_fill_caps=True;cu.bevel_resolution=0
 sp=cu.splines.new('POLY');sp.points.add(len(points)-1)
 for p,co in zip(sp.points,points):p.co=(*co,1)
 ob=bpy.data.objects.new(name,cu);col.objects.link(ob);bpy.ops.object.select_all(action='DESELECT');ob.select_set(True);bpy.context.view_layer.objects.active=ob;bpy.ops.object.convert(target='MESH');return finish(ob,name,mi)
def cyl(name,z,rad,depth,mi=3,verts=12):
 bpy.ops.mesh.primitive_cylinder_add(vertices=verts,radius=rad,depth=depth,location=(0,0,z));return finish(bpy.context.object,name,mi,.009)
def bolt(name,x,z,y):
 bpy.ops.mesh.primitive_uv_sphere_add(segments=8,ring_count=4,radius=.055,location=(x,y,z));ob=bpy.context.object;ob.scale=(1,.5,1);bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);return finish(ob,name,3)
# Molten forging is a continuous closed core. Basalt plates sit above it; fissures are true recesses.
contour=[(-.48,.87),(-.58,2.0),(-.60,4.3),(-.48,6.45),(-.20,7.1),(.28,7.60),(.72,6.26),(.88,5.54),(.73,5.38),(.86,5.24),(.80,4.52),(.69,4.44),(.82,4.26),(.73,3.43),(.61,3.36),(.73,3.16),(.60,2.36),(.48,2.30),(.57,2.16),(.39,1.12),(.23,.89)]
poly('Continuous obsidian forging',contour,.23,0,.012)
poly('Continuous ember core',[(x*.85,1.04+(z-1.04)*.975) for x,z in contour],.265,5,.009)
# Seven interlocking plates left and right; zigzag central fracture and branching seams.
levels=[1.02,1.73,2.83,3.57,4.65,5.38,6.35,7.10]
left=[-.46,-.55,-.58,-.59,-.57,-.54,-.47,-.19]
right=[.38,.53,.66,.75,.81,.85,.71,.44]
crack=[-.03,.09,-.12,.14,-.03,.19,.08,.19]
for j in range(7):
 z0,z1=levels[j],levels[j+1];a,b=crack[j],crack[j+1];l0,l1=left[j],left[j+1];r0,r1=right[j],right[j+1]
 lz0=z0+.14*sin(j*2.1);lz1=z1+.14*sin((j+1)*2.1);rz0=z0+.16*cos(j*1.9);rz1=z1+.16*cos((j+1)*1.9)
 mid=(z0+z1)/2;cm=(a+b)/2+(-.075 if j%2 else .09)
 poly('Obsidian spine slab %02d'%j,[(l0,lz0+.018),(a-.035,z0+.035),(cm-.035,mid-.07),(b-.035,z1-.025),(l1,lz1-.035)],.43,0,.009,facet=True)
 poly('Basalt fractured face %02d'%j,[(a+.035,z0+.035),(r0-.09,rz0+.022),(r1-.1,rz1-.032),(b+.03,z1-.038),(cm+.025,mid-.07)],.35,1,.01,facet=True)
 # Flint knapped broad cutting bevel, with intentional edge chips in three modules.
 edge=[(r0-.12,rz0+.015),(r0+.015,rz0+.055),(r1+.025,rz1-.055),(r1-.09,rz1-.02)]
 if j in [1,3,5]:edge.insert(2,((r0+r1)/2-.075,mid-.045));edge.insert(3,((r0+r1)/2+.025,mid+.075))
 poly('Chipped obsidian glass edge %02d'%j,edge,.18,2,.003,facet=True)
 # Narrow hotter center floats inside recessed orange channels, on front and back.
 for sy in [-1,1]:
  path('Deep incandescence',[(a,sy*.148,z0+.07),(cm,sy*.148,mid-.07),(b,sy*.148,z1-.04)],.012,6)
  if j in [1,3,5]:
   path('Lateral fault heat',[(a,sy*.147,z0+.018),((a+l0)*.5,sy*.147,(z0+lz0)*.5+.008),(l0+.07,sy*.147,lz0-.008)],.008,6)
  if j in [0,2,4,5]:
   path('Capillary fracture',[(cm+.04,sy*.245,mid-.06),(cm+.18,sy*.23,mid+.07),(cm+.24,sy*.22,mid+.20)],.012,5)
# Asymmetric high tip, thick spine tapers into volcanic spear-like terminal.
poly('Tip sealed crust',[(-.22,6.98),(.28,7.60),(.46,7.05),(.15,6.92)],.30,0,.004,facet=True)
poly('Terminal fractured obsidian',[(-.24,6.98),(.15,7.08),(.28,7.6),(.45,7.02),(.23,6.90)],.28,0,.005,facet=True)
poly('Tip glass cutting facet',[(.28,7.59),(.51,6.99),(.43,7.09),(.19,7.13)],.09,2,.003,facet=True)
# Deliberately unequal basalt guard. Recessed lava is visible at interrupted knuckle joints.
poly('Guard ember foundation',[(-1.24,.72),(-.9,.81),(-.3,1.05),(.35,1.05),(1.4,1.5),(1.12,1.00),(.58,.50),(-.35,.50),(-1.10,.37)],.28,5,.012)
for name,coords in [
 ('Left basalt hammer', [(-1.40,.88),(-.97,.89),(-.78,.54),(-1.12,.17),(-1.46,.29)]),
 ('Left guard root',[(-.93,.88),(-.31,1.10),(-.2,.49),(-.7,.38),(-.82,.58)]),
 ('Right guard root',[(.25,1.11),(.84,1.30),(1.02,.96),(.62,.43),(.21,.48)]),
 ('Right hooked basalt horn',[(.89,1.32),(1.58,1.77),(1.31,1.03),(1.06,.91)])]:
 poly(name,coords,.52,1,.028,facet=True)
# Copper structural brackets are heat darkened and riveted, asymmetrical rather than ornamental wings.
for x,z,w,h in [(-.55,.72,.12,.35),(.59,.86,.12,.37)]:
 for sy in [-1,1]:
  poly('Copper guard binding',[(x-w,z-h),(x+w,z-h+.04),(x+w,z+h),(x-w,z+h-.035)],.04,7,.01,y=sy*.31)
  for zz in [z-h+.085,z+h-.085]:bolt('Hammered copper rivet',x,zz,sy*.34)
# Socket: broad blunt octagon, recessed hot vent rather than a conventional jeweled guard.
poly('Socket ferrule',[(-.29,.27),(-.4,.55),(-.30,1.05),(.24,1.03),(.36,.53),(.23,.26)],.63,7,.035)
for sy in [-1,1]:
 poly('Socket dark face',[(-.22,.43),(-.25,.88),(.19,.89),(.22,.43)],.04,0,.015,y=sy*.35)
 for i in range(3):
  z=.49+i*.13
  poly('Cooling vent ember',[(-.15,z),(.14,z+.02),(.14,z+.061),(-.15,z+.04)],.018,6,.004,y=sy*.378)
# Long scorched grip, actual diagonal binding, slight taper and copper staples.
cyl('Grip top ferrule',.16,.24,.24,7)
cyl('Charred grip',-.68,.19,1.49,4,12)
for i in range(11):
 pts=[]
 for j in range(33):
  t=2*pi*j/32;pts.append((.202*cos(t),.202*sin(t),-1.37+i*.131+j/32*.125))
 path('Scorched leather wrap',pts,.031,4)
for z in [-1.48,-1.38,.04]:cyl('Burnished copper grip ring',z,.223,.085,3)
for sy in [-1,1]:
 for z in [-1.19,-.81,-.42]:
  poly('Grip copper staple',[(-.06,z-.018),(.06,z-.018),(.06,z+.018),(-.06,z+.018)],.016,7,.004,y=sy*.226)
# Pommel is a fractured basalt counterweight, copper butt cap and glowing broken seam.
poly('Pommel core',[(-.19,-1.48),(-.32,-1.72),(-.22,-2.08),(.11,-2.22),(.33,-1.98),(.27,-1.61)],.33,5,.015)
poly('Pommel upper basalt',[(-.19,-1.49),(-.34,-1.73),(-.23,-1.86),(.06,-1.77),(.29,-1.91),(.28,-1.62)],.43,1,.02,facet=True)
poly('Pommel lower basalt',[(-.24,-1.90),(.05,-1.83),(.31,-1.96),(.1,-2.24),(-.24,-2.09)],.43,0,.015,facet=True)
cyl('Pommel binding',-1.54,.247,.13,7)
# Shared 1024px tiled atlas. Face-local projection keeps each face wholly inside its material swatch.
for ob in parts:
 me=ob.data
 for layer in list(me.uv_layers):me.uv_layers.remove(layer)
 uv=me.uv_layers.new(name='CalderaAtlas');mi=ob['atlas'];ux=(mi%4)/4;uy=(mi//4)/2
 for face in me.polygons:
  axis=max(range(3),key=lambda i:abs(face.normal[i]));axes=[i for i in range(3) if i!=axis]
  coords=[me.vertices[me.loops[li].vertex_index].co for li in face.loop_indices]
  mins=[min(co[a] for co in coords) for a in axes];maxs=[max(co[a] for co in coords) for a in axes]
  for li,co in zip(face.loop_indices,coords):
   a=(co[axes[0]]-mins[0])/max(maxs[0]-mins[0],.01);b=(co[axes[1]]-mins[1])/max(maxs[1]-mins[1],.01)
   uv.data[li].uv=(ux+.014+a*.222,uy+.014+b*.472)
 bm=bmesh.new();bm.from_mesh(me);bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=.000001);bmesh.ops.dissolve_degenerate(bm,edges=list(bm.edges),dist=.000001);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(me);bm.free()
bpy.ops.object.select_all(action='DESELECT')
for ob in parts:ob.select_set(True)
bpy.context.view_layer.objects.active=parts[0];bpy.ops.object.join();weapon=bpy.context.object;weapon.name='Handle';weapon.data.name='Caldera_Mesh'
scene.cursor.location=(0,0,-.68);bpy.ops.object.origin_set(type='ORIGIN_CURSOR');weapon.location=(0,0,0);bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
master=bpy.data.materials.new('Caldera_PBR_Atlas');master.use_nodes=True;n=master.node_tree.nodes;l=master.node_tree.links;bs=n.get('Principled BSDF')
for typ in ['BaseColor','ORM','Normal','Emission']:
 tex=n.new('ShaderNodeTexImage');tex.image=ims[typ];tex.label=typ
 if typ=='BaseColor':l.new(tex.outputs['Color'],bs.inputs['Base Color'])
 if typ=='ORM':
  sep=n.new('ShaderNodeSeparateColor');l.new(tex.outputs['Color'],sep.inputs[0]);l.new(sep.outputs['Green'],bs.inputs['Roughness']);l.new(sep.outputs['Blue'],bs.inputs['Metallic'])
 if typ=='Normal':
  nm=n.new('ShaderNodeNormalMap');nm.inputs['Strength'].default_value=.45;l.new(tex.outputs['Color'],nm.inputs['Color']);l.new(nm.outputs['Normal'],bs.inputs['Normal'])
 if typ=='Emission':l.new(tex.outputs['Color'],bs.inputs['Emission Color']);bs.inputs['Emission Strength'].default_value=.55
weapon.data.materials.clear();weapon.data.materials.append(master)
for face in weapon.data.polygons:face.material_index=0
weapon['Design']='CALDERA | The faultline cleaver';weapon['Pivot']='Grip center; blade +Z, front -Y';weapon['Roblox']='One Handle MeshPart; 1024px UV0 tiled PBR atlas; emission optional and not supported by standard SurfaceAppearance.'
scene.unit_settings.system='NONE'
for channel,name in [(1,'Roughness'),(2,'Metalness')]:
 arr=np.ones((N,N,4),dtype=np.float32)
 for ch in range(3):arr[:,:,ch]=maps['ORM'][:,:,channel]
 im=bpy.data.images.new('Caldera_'+name,width=N,height=N,alpha=True);im.colorspace_settings.name='Non-Color';im.pixels.foreach_set(arr.ravel());im.filepath_raw=ROOT+'/Caldera_'+name+'.png';im.file_format='PNG';im.save();im.pack()
bpy.ops.export_scene.fbx(filepath=ROOT+'/Caldera_Sword.fbx',use_selection=True,add_leaf_bones=False,apply_unit_scale=True,axis_forward='Z',axis_up='Y',apply_scale_options='FBX_SCALE_UNITS',bake_anim=False,path_mode='COPY',embed_textures=True,object_types={'MESH'})
bpy.ops.export_scene.gltf(filepath=ROOT+'/Caldera_Sword.glb',export_format='GLB',use_selection=True,export_yup=True,export_texcoords=True,export_normals=True,export_materials='EXPORT')
bpy.ops.wm.obj_export(filepath=ROOT+'/Caldera_Sword.obj',export_selected_objects=True,export_materials=True,forward_axis='NEGATIVE_Z',up_axis='Y',path_mode='COPY')
for im in ims.values():im.pack()
# Neutral gallery with restrained warmth; emission not needed for silhouette or detail.
def move_studio(ob):
 for c in list(ob.users_collection):c.objects.unlink(ob)
 studio.objects.link(ob)
def area(name,loc,energy,color,size,target=(0,0,3)):
 bpy.ops.object.light_add(type='AREA',location=loc);ob=bpy.context.object;ob.name=name;move_studio(ob);ob.data.energy=energy;ob.data.color=color;ob.data.shape='DISK';ob.data.size=size;ob.rotation_euler=(Vector(target)-ob.location).to_track_quat('-Z','Y').to_euler()
area('Warm key',(-4,-6,8),1350,(1,.77,.59),5)
area('Cool edge',(4,2,6),1500,(.48,.64,1),4)
area('Face softbox',(4,-5,3),900,(.8,.85,1),5)
area('Pommel lift',(-2,-4,-1),300,(1,.47,.20),3)
world=bpy.data.worlds.new('Charcoal gallery');scene.world=world;world.use_nodes=True;world.node_tree.nodes['Background'].inputs[0].default_value=(.021,.027,.038,1);world.node_tree.nodes['Background'].inputs[1].default_value=.45
bpy.ops.object.camera_add(location=(5,-28,7));cam=bpy.context.object;cam.name='CAMERA | Hero';move_studio(cam);scene.camera=cam;cam.data.type='ORTHO';cam.data.ortho_scale=11.3
cam.rotation_euler=(Vector((0,0,3.35))-cam.location).to_track_quat('-Z','Y').to_euler()
scene.render.engine='CYCLES';scene.cycles.samples=64;scene.cycles.use_denoising=False;scene.render.threads_mode='FIXED';scene.render.threads=4
scene.render.resolution_x=1400;scene.render.resolution_y=1800;scene.render.resolution_percentage=100;scene.view_settings.view_transform='AgX';scene.render.image_settings.file_format='PNG'
bpy.ops.object.select_all(action='DESELECT');weapon.select_set(True);bpy.context.view_layer.objects.active=weapon
for screen in bpy.data.screens:
 for ar in screen.areas:
  if ar.type=='VIEW_3D':ar.spaces.active.region_3d.view_perspective='CAMERA'
scene.render.filepath=ROOT+'/Caldera_Hero.png';bpy.ops.wm.save_as_mainfile(filepath=ROOT+'/Caldera_Sword.blend')
bm=bmesh.new();bm.from_mesh(weapon.data)
stats={'vertices':len(weapon.data.vertices),'polygons':len(weapon.data.polygons),'triangles':sum(len(p.vertices)-2 for p in weapon.data.polygons),'dimensions':list(weapon.dimensions),'materials':len(weapon.data.materials),'boundary_edges':sum(e.is_boundary for e in bm.edges),'nonmanifold_edges':sum(not e.is_manifold for e in bm.edges),'uv_layers':len(weapon.data.uv_layers)};bm.free()
open(ROOT+'/model_stats.json','w').write(json.dumps(stats,indent=2))
bpy.ops.render.render(write_still=True)
cam.location=(2.5,-20,3.3);target=Vector((0,0,1.3));cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.ortho_scale=5.5;scene.render.resolution_x=1500;scene.render.resolution_y=1400;scene.render.filepath=ROOT+'/Caldera_Detail.png';bpy.ops.render.render(write_still=True)
cam.location=(0,-25,3.35);cam.rotation_euler=(Vector((0,0,3.35))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.ortho_scale=11.3;scene.render.resolution_x=1200;scene.render.resolution_y=1800;scene.render.filepath=ROOT+'/Caldera_Front.png';bpy.ops.render.render(write_still=True)
print('CALDERA_BUILD_COMPLETE',stats)
