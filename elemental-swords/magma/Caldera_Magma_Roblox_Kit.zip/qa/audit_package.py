from PIL import Image,ImageChops
from pathlib import Path
import json,hashlib,zipfile,sys,struct
root=Path(sys.argv[1]);out=Path(sys.argv[2]);report={};textures={}
for p in sorted(root.glob('*.png')):
 if any(k.lower() in p.name.lower() for k in ['BaseColor','Metalness','Roughness','Normal','ORM']):
  im=Image.open(p);im.load();textures[p.name]={'size':im.size,'mode':im.mode,'extrema':im.getextrema()}
report['textures']=textures
for op in root.glob('*ORM.png'):
 prefix=op.name[:-7];orm=Image.open(op).convert('RGB')
 for label,channel in [('Metalness','B'),('Roughness','G')]:
  p=root/(prefix+label+'.png')
  if p.exists():report[label+'_matches_ORM']=all(ImageChops.difference(orm.getchannel(channel),c).getbbox() is None for c in Image.open(p).convert('RGB').split())
for p in root.glob('*.glb'):
 b=p.read_bytes();magic,version,size=struct.unpack('<4sII',b[:12]);n,t=struct.unpack('<II',b[12:20]);gltf=json.loads(b[20:20+n]);report['glb']={'magic':magic.decode(),'version':version,'declared_size_matches':size==len(b),'meshes':len(gltf.get('meshes',[])),'materials':gltf.get('materials',[]),'images':gltf.get('images',[]),'cameras':gltf.get('cameras',[]),'animations':gltf.get('animations',[])}
report['files']={p.relative_to(root).as_posix():{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(root.rglob('*')) if p.is_file() and p.suffix not in ['.zip','.blend1','.log','.pyc'] and '__pycache__' not in p.parts and p.name not in ['make_builder.py','write_builder.py']}
report['zips']=[]
for p in root.glob('*.zip'):
 with zipfile.ZipFile(p) as z:
  names=z.namelist();files=[n for n in names if not n.endswith('/')];roots={n.split('/')[0] for n in names};prefix=next(iter(roots))+'/' if len(roots)==1 and all('/' in n for n in files) else ''
  rels={n[len(prefix):] for n in files};expected=set(report['files'])
  r={'file':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'crc_failure':z.testzip(),'contents':names,'unsafe_paths':[x for x in names if x.startswith('/') or '..' in Path(x).parts],'missing':sorted(expected-rels),'extra':sorted(rels-expected),'disk_mismatches':[n for n in files if not (root/n[len(prefix):]).is_file() or z.read(n)!=(root/n[len(prefix):]).read_bytes()],'duplicate_members':len(names)!=len(set(names))}
  r['passed']=not any(r[x] for x in ['crc_failure','unsafe_paths','missing','extra','disk_mismatches','duplicate_members']);report['zips'].append(r)
report['studio_tested']=False
out.write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
