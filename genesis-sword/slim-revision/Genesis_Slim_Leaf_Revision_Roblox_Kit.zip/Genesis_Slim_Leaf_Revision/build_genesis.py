import bpy, math, os, random
from mathutils import Vector
from math import sin,cos,pi
ROOT=os.path.dirname(os.path.abspath(__file__))
os.makedirs(ROOT,exist_ok=True)
bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
for d in bpy.data.materials: bpy.data.materials.remove(d)
scene=bpy.context.scene
col=bpy.data.collections.new('GENESIS | EXPORT'); scene.collection.children.link(col)
studio=bpy.data.collections.new('STUDIO | DO NOT EXPORT');scene.collection.children.link(studio)
# One transportable color atlas and packed ORM, with deliberate hand-designed color families.
palette=[('Lunar Silver',(.64,.73,.80),.88,.25),('Antique Celestial Gold',(.72,.43,.13),.85,.25),('Ivory Enamel',(.89,.88,.75),.25,.3),('Deep Midnight Leather',(.028,.049,.071),.05,.59),('Aether Crystal',(.12,.72,.92),.45,.2),('Obsidian Recess',(.012,.025,.04),.35,.4),('Pale Gold Highlight',(.94,.70,.29),.8,.22),('White Core',(.61,.93,1),.25,.19)]
N=512
base=bpy.data.images.new('Genesis_BaseColor',width=N,height=N,alpha=True)
orm=bpy.data.images.new('Genesis_ORM',width=N,height=N,alpha=True)
normal=bpy.data.images.new('Genesis_Normal',width=N,height=N,alpha=True)
pix=[]; opix=[];npix=[]
random.seed(12)
for y in range(N):
 for x in range(N):
  k=(x//128)+4*(y//256); name,c,m,r=palette[k]
  grain=(random.random()-.5)*.025
  # Directional fine brushed metal and leather texture; restrained so edges carry the form.
  v=grain + (.009*sin(y*.85) if m>.7 else .006*sin(x*.9)*sin(y*.72))
  pix.extend([max(0,min(1,q+v)) for q in c]+[1]);opix.extend([1,r,m,1]);npix.extend([.5,.5,1,1])
for im,p,name in [(base,pix,'Genesis_BaseColor.png'),(orm,opix,'Genesis_ORM.png'),(normal,npix,'Genesis_Normal.png')]:
 
 if im != base:im.colorspace_settings.name='Non-Color'
 im.pixels=p; im.filepath_raw=os.path.join(ROOT,name);im.file_format='PNG';im.save()
orm.colorspace_settings.name='Non-Color';normal.colorspace_settings.name='Non-Color'
mats=[]
for k,(name,c,m,r) in enumerate(palette):
 mat=bpy.data.materials.new(name); mat.diffuse_color=(*c,1);mat.use_nodes=True
 n=mat.node_tree.nodes; l=mat.node_tree.links; bs=n.get('Principled BSDF');tex=n.new('ShaderNodeTexImage');tex.image=base
 l.new(tex.outputs['Color'],bs.inputs['Base Color']);bs.inputs['Metallic'].default_value=m;bs.inputs['Roughness'].default_value=r
 # Add ORM mapping so GLB exports metallic/roughness texture data.
 packed=n.new('ShaderNodeTexImage');packed.image=orm;sep=n.new('ShaderNodeSeparateColor');l.new(packed.outputs['Color'],sep.inputs[0]);l.new(sep.outputs['Green'],bs.inputs['Roughness']);l.new(sep.outputs['Blue'],bs.inputs['Metallic'])
 if k in [4,7]:
  l.new(tex.outputs['Color'],bs.inputs['Emission Color']);bs.inputs['Emission Strength'].default_value=.6 if k==4 else 1.6
 mats.append(mat)
parts=[]
def finish(obj,name,mi=0,bev=0):
 obj.name=name
 for c in list(obj.users_collection): c.objects.unlink(obj)
 col.objects.link(obj);obj.data.materials.clear();obj.data.materials.append(mats[mi]);parts.append(obj)
 if bev:
  mod=obj.modifiers.new('Machined light-catching edges','BEVEL');mod.width=bev;mod.segments=2
  bpy.context.view_layer.objects.active=obj;bpy.ops.object.modifier_apply(modifier=mod.name)
 # Flat faces keep precision-cut planes; bevels provide the specular transitions.
 return obj

def poly(name,coords,thick,mi=0,bev=.012,y=0):
 # Front contour viewed along Y, extruded for a genuine closed mesh.
 n=len(coords);v=[(x,y-thick/2,z) for x,z in coords]+[(x,y+thick/2,z) for x,z in coords]
 f=[tuple(range(n-1,-1,-1)),tuple(range(n,n*2))]+[(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)]
 me=bpy.data.meshes.new(name);me.from_pydata(v,[],f);me.update();ob=bpy.data.objects.new(name,me);col.objects.link(ob);return finish(ob,name,mi,bev)
def path(name,points,r=.018,mi=1,sides=6):
 # Tubular filigree follows intentional traced architectural paths.
 cu=bpy.data.curves.new(name,'CURVE');cu.dimensions='3D';cu.resolution_u=1;cu.bevel_depth=r;cu.use_fill_caps=True;cu.bevel_resolution=0;cu.resolution_u=1
 sp=cu.splines.new('POLY');sp.points.add(len(points)-1)
 for p,co in zip(sp.points,points):p.co=(*co,1)
 ob=bpy.data.objects.new(name,cu);col.objects.link(ob);bpy.context.view_layer.objects.active=ob;ob.select_set(True);bpy.ops.object.convert(target='MESH');ob.select_set(False);return finish(ob,name,mi)
def cyl(name,z,rad,depth,mi=1,verts=12):
 bpy.ops.mesh.primitive_cylinder_add(vertices=verts,radius=rad,depth=depth,location=(0,0,z));return finish(bpy.context.object,name,mi,.014)
def gem(name,x,z,w,h,mi=4,y=-.1):
 # Faceted, double-pyramid crystal with strong diamond silhouette.
 vs=[(x-w,y,z),(x,y,z+h),(x+w,y,z),(x,y,z-h),(x,y-.14,z),(x,y+.1,z)]
 fs=[(0,1,4),(1,2,4),(2,3,4),(3,0,4),(1,0,5),(2,1,5),(3,2,5),(0,3,5)]
 me=bpy.data.meshes.new(name);me.from_pydata(vs,[],fs);ob=bpy.data.objects.new(name,me);col.objects.link(ob);return finish(ob,name,mi)
# Sketch-led Roman leaf blade. Single closed, continuous volume with a raised spine.
# Width spline contracts above the guard, then subtly swells in the upper half.
# Slim revision: upper peak 0.47 half-width (was 0.65, -27.7%); waist and base unchanged.
profile=[(.85,.37),(1.18,.32),(1.55,.265),(2.05,.25),(2.60,.275),(3.20,.315),(3.80,.365),(4.40,.42),(5.0,.46),(5.50,.47),(5.90,.445),(6.25,.365),(6.60,.235),(7.15,0)]
secants=[(profile[i+1][1]-profile[i][1])/(profile[i+1][0]-profile[i][0]) for i in range(len(profile)-1)]
slopes=[secants[0]]
for i in range(1,len(profile)-1):
 a,b=secants[i-1],secants[i]
 slopes.append(2*a*b/(a+b) if a*b>0 else 0)
slopes.append(secants[-1])
def width_at(z):
 for i in range(len(profile)-1):
  z0,w0=profile[i];z1,w1=profile[i+1]
  if z<=z1:
   t=(z-z0)/(z1-z0)
   h=z1-z0
   return (2*t**3-3*t*t+1)*w0+(t**3-2*t*t+t)*h*slopes[i]+(-2*t**3+3*t*t)*w1+(t**3-t*t)*h*slopes[i+1]
 return 0
stations=[]
for i in range(len(profile)-1):
 for j in range(4):
  z=profile[i][0]+(profile[i+1][0]-profile[i][0])*j/4
  stations.append((z,width_at(z)))
verts=[]
# Eight-sided lenticular section: central ridge, broad forged faces, crisp edge bevel.
for z,w in stations:
 d=.15*min(1,w/.26)
 verts.extend([(0,-d,z),(.77*w,-d*.42,z),(w,0,z),(.77*w,d*.42,z),(0,d,z),(-.77*w,d*.42,z),(-w,0,z),(-.77*w,-d*.42,z)])
faces=[tuple(range(7,-1,-1))]
for j in range(len(stations)-1):
 for k in range(8):faces.append((j*8+k,j*8+(k+1)%8,(j+1)*8+(k+1)%8,(j+1)*8+k))
tip=len(verts);verts.append((0,0,7.15))
for k in range(8):faces.append(((len(stations)-1)*8+k,(len(stations)-1)*8+(k+1)%8,tip))
me=bpy.data.meshes.new('Genesis continuous leaf forging');me.from_pydata(verts,[],faces);me.update();ob=bpy.data.objects.new('Leaf blade | integral raised ridge',me);col.objects.link(ob);finish(ob,ob.name,0)
# Smooth only along the blade length. Sharp longitudinal creases preserve ridge and bevels.
for p in me.polygons:p.use_smooth=True
for edge in me.edges:
 a,b=edge.vertices
 if a==tip or b==tip or (a%8==b%8) or (a<8 and b<8):edge.use_edge_sharp=True
# Gold channels follow the silhouette along the broad face; accents are intentionally spare.
for sy in [-1,1]:
 for sx in [-1,1]:
  points=[]
  for j in range(55):
   z=1.20+(6.70-1.20)*j/54;w=width_at(z);x=.60*w
   d=.15*min(1,w/.26)
   points.append((sx*x,sy*(d*(1-.58*.60/.77)+.004),z))
  path('Leaf-following gilt inlay',points,.010,1)
 # Very thin cyan highlight on the highest ridge; follows blade thickness to the point.
 points=[]
 for j in range(57):
  z=1.22+(6.95-1.22)*j/56;w=width_at(z)
  points.append((0,sy*(.15*min(1,w/.26)+.004),z))
 path('Aether ridge filament',points,.012,4)
 for z in [2.05,3.1,4.15,5.25]:
  w=width_at(z);d=.15
  for sx in [-1,1]:
   path('Gilt seed engraving',[(sx*.17*w,sy*(d*.9+.005),z+.10),(sx*.30*w,sy*(d*.78+.005),z),(sx*.43*w,sy*(d*.68+.005),z+.10)],.008,6)
# Sketch's swept-up crescent wings, kept clear of the new narrow waist.
wing=[(.17,.93),(.44,.86),(.77,.88),(1.08,.97),(1.39,1.10),(1.78,1.31),(1.53,.96),(1.24,.66),(.91,.40),(.53,.21),(.20,.15)]
for sx in [-1,1]:
 poly('Ascending seraph wing',[(sx*x,z) for x,z in wing],.23,0,.018,y=.045)
 inset=[(.43,.68),(.78,.70),(1.10,.82),(1.50,1.10),(1.22,.76),(.88,.48),(.53,.34)]
 for sy in [-1,1]:
  poly('Ivory swept feather',[(sx*x,z) for x,z in inset],.025,2,.009,y=.045+sy*.13)
  path('Wing crown gold contour',[(sx*.31,.045+sy*.147,.83),(sx*.76,.045+sy*.147,.79),(sx*1.08,.045+sy*.147,.90),(sx*1.57,.045+sy*.10,1.18)],.018,1)
  path('Wing lower gold contour',[(sx*.44,.045+sy*.148,.30),(sx*.85,.045+sy*.148,.45),(sx*1.20,.045+sy*.148,.73)],.012,1)
 gem('Guard satellite',sx*.86,.57,.063,.09,4,-.117)
# Cathedral-like central collar with layered geometry and azure focus.
poly('Guard central cathedral',[(-.23,.18),(-.34,.53),(-.25,.99),(0,1.28),(.25,.99),(.34,.53),(.23,.18)],.26,1,.016)
poly('Guard inset enamel',[(-.15,.31),(-.23,.56),(-.16,.91),(0,1.10),(.16,.91),(.23,.56),(.15,.31)],.036,5,.01,y=-.152)
gem('Genesis heart',0,.71,.135,.3,4,-.184)
for sy in [-1,1]:
 path('Collar nested arch',[(-.19,sy*.185,.42),(-.19,sy*.185,.88),(0,sy*.185,1.16),(.19,sy*.185,.88),(.19,sy*.185,.42)],.018,6)
# Hand-length grip: subtle taper, actual helical wrap with alternating seams.
cyl('Grip upper ferrule',.11,.203,.20,1)
cyl('Octagonal leather grip',-.65,.151,1.32,3,12)
for i in range(12):
 z=-1.24+i*.108
 pts=[]
 for j in range(49):
  t=j/48*2*pi;pts.append((.158*cos(t),.158*sin(t),z+j/48*.10))
 path('Raised leather spiral',pts,.022,3)
for z in [-1.35,-1.26,-.02]:cyl('Engraved grip ferrule',z,.185,.065,1)
# Front and back gold grip splines, distinct diamond insets.
for sy in [-1,1]:
 path('Grip spine inlay',[(0,sy*.173,-1.19),(0,sy*.173,-.10)],.014,1)
 for z in [-.29,-.66,-1.02]:gem('Grip lozenge',0,z,.044,.068,6,sy*.179)
# Open aureole pommel with a floating elongated teardrop crystal.
poly('Pommel crown',[(-.18,-1.34),(-.29,-1.54),(-.19,-1.67),(0,-1.49),(.19,-1.67),(.29,-1.54),(.18,-1.34)],.18,1,.017)
for s in [-1,1]:
 poly('Pommel carved cage',[(s*.11,-1.50),(s*.28,-1.66),(s*.25,-1.90),(0,-2.19),(s*.13,-1.86),(s*.16,-1.70)],.15,0,.012)
 path('Pommel gilt rim',[(s*.13,-.09,-1.51),(s*.26,-.09,-1.68),(s*.23,-.09,-1.87),(0,-.09,-2.17)],.014,1)
gem('Genesis seed crystal',0,-1.80,.115,.24,4,-.005)
gem('Pommel star tip',0,-2.18,.065,.095,6,0)
# UV atlas per material. Triplanar projection yields non-overlapping swatch families.
for ob in parts:
 me=ob.data
 uv=me.uv_layers.new(name='GenesisAtlas')
 mi=palette.index(next(p for p in palette if p[0]==me.materials[0].name))
 ux=(mi%4)/4;uy=(mi//4)/2
 for face in me.polygons:
  normalvec=face.normal;axis=max(range(3),key=lambda i:abs(normalvec[i]));axes=[i for i in range(3) if i!=axis]
  for li in face.loop_indices:
   co=me.vertices[me.loops[li].vertex_index].co
   a=(co[axes[0]]*.63)%1;b=(co[axes[1]]*.41)%1
   uv.data[li].uv=(ux+.015+a*.22,uy+.015+b*.47)
# Clean each closed component independently, preserving contact boundaries.
import bmesh
for ob in parts:
 for layer in list(ob.data.uv_layers):
  if layer.name != 'GenesisAtlas':ob.data.uv_layers.remove(layer)
 ob.data.uv_layers.active=ob.data.uv_layers.get('GenesisAtlas')
 bm=bmesh.new();bm.from_mesh(ob.data)
 bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=.000001)
 bmesh.ops.dissolve_degenerate(bm,edges=list(bm.edges),dist=.000001)
 bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(ob.data);bm.free();ob.data.update()
# Bake object transforms, set handle-centered origin: Y front/back, Z blade-up.
bpy.ops.object.select_all(action='DESELECT')
for ob in parts: ob.select_set(True)
bpy.context.view_layer.objects.active=parts[0]
bpy.ops.object.join();weapon=bpy.context.object;weapon.name='Genesis_Sword';weapon.data.name='Genesis_Sword_Mesh'
scene.cursor.location=(0,0,-.66);bpy.ops.object.origin_set(type='ORIGIN_CURSOR');weapon.location=(0,0,0)
bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
# Consolidate portable shader: all metals, enamel and leather are encoded in one atlas.
weapon.name='Handle'
master=mats[0].copy();master.name='Genesis_PBR_Atlas'
weapon.data.materials.clear();weapon.data.materials.append(master)
for face in weapon.data.polygons:face.material_index=0
import bmesh
bm=bmesh.new();bm.from_mesh(weapon.data)
bmesh.ops.dissolve_degenerate(bm,edges=list(bm.edges),dist=.000001)
bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(weapon.data);bm.free();weapon.data.update()
# Mesh custom metadata included in editable source.
weapon['Design']='GENESIS • Slim leaf revision, proportion-refined Roman celestial relic';weapon['Pivot']='Grip center; +Z toward blade, front -Y';weapon['Roblox']='One MeshPart. Import scale as needed; use supplied PBR maps in SurfaceAppearance.'
weapon['Texture']='UV0: shared 512px atlas. Cyan is PBR color; source emission is optional.'
scene.unit_settings.system='NONE';scene.unit_settings.scale_length=1
# Exports: only actual sword selected.
bpy.ops.export_scene.fbx(filepath=ROOT+'/Genesis_Sword.fbx',use_selection=True,add_leaf_bones=False,apply_unit_scale=True,axis_forward='Z',axis_up='Y',apply_scale_options='FBX_SCALE_UNITS',bake_anim=False,path_mode='COPY',embed_textures=True,object_types={'MESH'},use_mesh_modifiers=True)
bpy.ops.export_scene.gltf(filepath=ROOT+'/Genesis_Sword.glb',export_format='GLB',use_selection=True,export_yup=True,export_texcoords=True,export_normals=True,export_materials='EXPORT')
bpy.ops.wm.obj_export(filepath=ROOT+'/Genesis_Sword.obj',export_selected_objects=True,export_materials=True,forward_axis='NEGATIVE_Z',up_axis='Y',path_mode='COPY')
# Readable companion maps for Roblox SurfaceAppearance.
for channel,name in [(1,'Genesis_Roughness.png'),(2,'Genesis_Metalness.png')]:
 im=bpy.data.images.new(name,width=N,height=N,alpha=True);ps=[]
 for i in range(N*N):v=opix[i*4+channel];ps.extend([v,v,v,1])
 im.colorspace_settings.name='Non-Color';im.pixels=ps;im.filepath_raw=ROOT+'/'+name;im.file_format='PNG';im.save();im.pack()
base.pack();orm.pack();normal.pack()
# Museum-style lighting and background, never part of the export.
def move_studio(ob):
 for c in list(ob.users_collection):c.objects.unlink(ob)
 studio.objects.link(ob)
def area(name,loc,energy,color,size,target=(0,0,2.7)):
 bpy.ops.object.light_add(type='AREA',location=loc);ob=bpy.context.object;ob.name=name;move_studio(ob);ob.data.energy=energy;ob.data.color=color;ob.data.shape='DISK';ob.data.size=size;ob.rotation_euler=(Vector(target)-ob.location).to_track_quat('-Z','Y').to_euler()
area('Key | warm softbox',(-4,-5,7),1000,(1,.87,.66),5)
area('Edge | cold strip',(3,1,6),1350,(.29,.64,1),4)
area('Fill | blue silver',(3,-5,2),650,(.52,.76,1),4)
area('Pommel kicker',(-2,-2,-1),180,(.4,.77,1),2)
world=bpy.data.worlds.new('Midnight gallery') if not bpy.data.worlds else bpy.data.worlds[0];scene.world=world;world.use_nodes=True;world.node_tree.nodes['Background'].inputs[0].default_value=(.017,.024,.041,1);world.node_tree.nodes['Background'].inputs[1].default_value=.4
bpy.ops.object.camera_add(location=(5,-28,7));cam=bpy.context.object;cam.name='CAMERA | Hero';move_studio(cam);scene.camera=cam
cam.data.type='ORTHO';cam.data.ortho_scale=10.8
cam.rotation_euler=(Vector((0,0,3.05))-cam.location).to_track_quat('-Z','Y').to_euler()
scene.render.engine='CYCLES';scene.cycles.samples=128;scene.cycles.use_denoising=False
scene.render.resolution_x=1400;scene.render.resolution_y=1800;scene.render.resolution_percentage=100
scene.view_settings.view_transform='AgX'
scene.render.image_settings.file_format='PNG';scene.render.film_transparent=False
# Compositor restrained glow only affects preview, with no promised Roblox bloom.
scene.use_nodes=True;nodes=scene.node_tree.nodes;nodes.clear();rl=nodes.new('CompositorNodeRLayers');g=nodes.new('CompositorNodeGlare');g.glare_type='FOG_GLOW';g.quality='HIGH';g.threshold=1.7;g.mix=-.92;o=nodes.new('CompositorNodeComposite');scene.node_tree.links.new(rl.outputs['Image'],g.inputs[0]);scene.node_tree.links.new(g.outputs[0],o.inputs[0])
bpy.ops.object.select_all(action='DESELECT');weapon.select_set(True);bpy.context.view_layer.objects.active=weapon
# Home view aligned to camera and saved source with image textures packed.
for screen in bpy.data.screens:
 for ar in screen.areas:
  if ar.type=='VIEW_3D':ar.spaces.active.region_3d.view_perspective='CAMERA'
scene.render.filepath=ROOT+'/Genesis_Hero.png'
bpy.ops.wm.save_as_mainfile(filepath=ROOT+'/Genesis_Sword.blend')
tris=sum(len(p.vertices)-2 for p in weapon.data.polygons)
with open(ROOT+'/model_stats.txt','w') as f:f.write(f'Vertices: {len(weapon.data.vertices)}\nPolygons: {len(weapon.data.polygons)}\nTriangles: {tris}\nDimensions: {tuple(weapon.dimensions)}\nMaterials: {len(weapon.data.materials)}\n')
bpy.ops.render.render(write_still=True)
cam.location=(2.4,-16,4.1);target=Vector((0,0,1.09));cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.ortho_scale=4.9
scene.render.resolution_x=1600;scene.render.resolution_y=1400;scene.render.filepath=ROOT+'/Genesis_Detail.png';bpy.ops.render.render(write_still=True)
# A front orthographic view records the approved silhouette without perspective distortion.
cam.location=(0,-25,3.10);target=Vector((0,0,3.10));cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.ortho_scale=10.8
scene.render.resolution_x=1200;scene.render.resolution_y=1800;scene.render.filepath=ROOT+'/Genesis_Front.png';bpy.ops.render.render(write_still=True)
print('GENESIS_BUILD_COMPLETE')
