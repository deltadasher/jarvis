import bpy,bmesh,json,os,sys,math,hashlib
root,out=sys.argv[sys.argv.index('--')+1:]
reports=[]
for ext in ['fbx','obj','glb']:
 p=os.path.join(root,'Genesis_Sword.'+ext)
 bpy.ops.wm.read_factory_settings(use_empty=True)
 if ext=='fbx':bpy.ops.import_scene.fbx(filepath=p)
 elif ext=='glb':bpy.ops.import_scene.gltf(filepath=p)
 else:bpy.ops.wm.obj_import(filepath=p)
 r={'file':os.path.basename(p),'sha256':hashlib.sha256(open(p,'rb').read()).hexdigest(),'objects':[(x.name,x.type) for x in bpy.context.scene.objects],'meshes':[]}
 for ob in bpy.context.scene.objects:
  if ob.type!='MESH':continue
  me=ob.data;me.calc_loop_triangles();bm=bmesh.new();bm.from_mesh(me)
  raw_nonmanifold=sum(not e.is_manifold for e in bm.edges)
  # glTF duplicates vertex positions at UV/normal seams. Audit welded topology separately.
  bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=1e-6);bm.normal_update()
  visited=set();volumes=[];counts=[]
  for start in bm.verts:
   if start in visited:continue
   stack=[start];vs=set();fs=set()
   while stack:
    v=stack.pop()
    if v in visited:continue
    visited.add(v);vs.add(v);fs.update(v.link_faces)
    stack.extend(e.other_vert(v) for e in v.link_edges if e.other_vert(v) not in visited)
   volume=0
   for f in fs:
    a=f.verts[0].co
    for i in range(1,len(f.verts)-1):volume+=a.dot(f.verts[i].co.cross(f.verts[i+1].co))/6
   volumes.append(volume);counts.append(len(fs))
  coords=[ob.matrix_world@v.co for v in me.vertices]
  tris=[((me.vertices[t.vertices[1]].co-me.vertices[t.vertices[0]].co).cross(me.vertices[t.vertices[2]].co-me.vertices[t.vertices[0]].co)).length/2 for t in me.loop_triangles]
  row={'name':ob.name,'vertices':len(me.vertices),'triangles':len(tris),'degenerate_triangles':sum(a<1e-12 for a in tris),'raw_nonmanifold_edges':raw_nonmanifold,'welded_nonmanifold_edges':sum(not e.is_manifold for e in bm.edges),'boundary_edges':sum(e.is_boundary for e in bm.edges),'inconsistent_winding_edges':sum(e.is_manifold and not e.is_contiguous for e in bm.edges),'loose_vertices':sum(not v.link_faces for v in bm.verts),'connected_components':len(volumes),'negative_component_volumes':sum(v< -1e-10 for v in volumes),'zero_component_volumes':sum(abs(v)<=1e-10 for v in volumes),'signed_volume':sum(volumes),'origin':list(ob.matrix_world.translation),'dimensions':[max(p[i] for p in coords)-min(p[i] for p in coords) for i in range(3)],'bounds':[[min(p[i] for p in coords) for i in range(3)],[max(p[i] for p in coords) for i in range(3)]],'finite':all(math.isfinite(v) for p in coords for v in p),'material_names':[m.name for m in me.materials],'material_indices':sorted(set(p.material_index for p in me.polygons)),'uv_layers':len(me.uv_layers),'uv_bounds':[{ 'min':[min(x.uv[i] for x in u.data) for i in range(2)],'max':[max(x.uv[i] for x in u.data) for i in range(2)]} for u in me.uv_layers],'normal_length_range':[min(v.normal.length for v in me.vertices),max(v.normal.length for v in me.vertices)]}
  r['meshes'].append(row);bm.free()
 reports.append(r)
json.dump({'validation':'Independent Blender reimport, not Roblox Studio testing','blender_version':bpy.app.version_string,'exports':reports},open(out,'w'),indent=2)
