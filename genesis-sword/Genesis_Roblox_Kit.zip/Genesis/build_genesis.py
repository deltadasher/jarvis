import bpy, math, os, random
from mathutils import Vector
from math import sin,cos,pi
ROOT=os.path.dirname(os.path.abspath(__file__))
os.makedirs(ROOT,exist_ok=True)
bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
for d in bpy.data.materials: bpy.data.materials.remove(d)
scene=bpy.context.scene
col=bpy.data.collections.new('GENESIS | EXPORT'); scene.collection.children.link(col)
studio=bpy.data.collections.new('STUDIO | DO NOT EXPORT');scene.collection.children.link(studio)
# One transportable color atlas and packed ORM, with deliberate hand-designed color families.
palette=[('Lunar Silver',(.64,.73,.80),.88,.25),('Antique Celestial Gold',(.72,.43,.13),.85,.25),('Ivory Enamel',(.89,.88,.75),.25,.3),('Deep Midnight Leather',(.028,.049,.071),.05,.59),('Aether Crystal',(.12,.72,.92),.45,.2),('Obsidian Recess',(.012,.025,.04),.35,.4),('Pale Gold Highlight',(.94,.70,.29),.8,.22),('White Core',(.61,.93,1),.25,.19)]
N=512
base=bpy.data.images.new('Genesis_BaseColor',width=N,height=N,alpha=True)
orm=bpy.data.images.new('Genesis_ORM',width=N,height=N,alpha=True)
normal=bpy.data.images.new('Genesis_Normal',width=N,height=N,alpha=True)
pix=[]; opix=[];npix=[]
random.seed(12)
for y in range(N):
 for x in range(N):
  k=(x//128)+4*(y//256); name,c,m,r=palette[k]
  grain=(random.random()-.5)*.025
  # Directional fine brushed metal and leather texture; restrained so edges carry the form.
  v=grain + (.009*sin(y*.85) if m>.7 else .006*sin(x*.9)*sin(y*.72))
  pix.extend([max(0,min(1,q+v)) for q in c]+[1]);opix.extend([1,r,m,1]);npix.extend([.5,.5,1,1])
for im,p,name in [(base,pix,'Genesis_BaseColor.png'),(orm,opix,'Genesis_ORM.png'),(normal,npix,'Genesis_Normal.png')]:
 
 if im != base:im.colorspace_settings.name='Non-Color'
 im.pixels=p; im.filepath_raw=os.path.join(ROOT,name);im.file_format='PNG';im.save()
orm.colorspace_settings.name='Non-Color';normal.colorspace_settings.name='Non-Color'
mats=[]
for k,(name,c,m,r) in enumerate(palette):
 mat=bpy.data.materials.new(name); mat.diffuse_color=(*c,1);mat.use_nodes=True
 n=mat.node_tree.nodes; l=mat.node_tree.links; bs=n.get('Principled BSDF');tex=n.new('ShaderNodeTexImage');tex.image=base
 l.new(tex.outputs['Color'],bs.inputs['Base Color']);bs.inputs['Metallic'].default_value=m;bs.inputs['Roughness'].default_value=r
 # Add ORM mapping so GLB exports metallic/roughness texture data.
 packed=n.new('ShaderNodeTexImage');packed.image=orm;sep=n.new('ShaderNodeSeparateColor');l.new(packed.outputs['Color'],sep.inputs[0]);l.new(sep.outputs['Green'],bs.inputs['Roughness']);l.new(sep.outputs['Blue'],bs.inputs['Metallic'])
 if k in [4,7]:
  l.new(tex.outputs['Color'],bs.inputs['Emission Color']);bs.inputs['Emission Strength'].default_value=.6 if k==4 else 1.6
 mats.append(mat)
parts=[]
def finish(obj,name,mi=0,bev=0):
 obj.name=name
 for c in list(obj.users_collection): c.objects.unlink(obj)
 col.objects.link(obj);obj.data.materials.clear();obj.data.materials.append(mats[mi]);parts.append(obj)
 if bev:
  mod=obj.modifiers.new('Machined light-catching edges','BEVEL');mod.width=bev;mod.segments=2
  bpy.context.view_layer.objects.active=obj;bpy.ops.object.modifier_apply(modifier=mod.name)
 # Flat faces keep precision-cut planes; bevels provide the specular transitions.
 return obj

def poly(name,coords,thick,mi=0,bev=.012,y=0):
 # Front contour viewed along Y, extruded for a genuine closed mesh.
 n=len(coords);v=[(x,y-thick/2,z) for x,z in coords]+[(x,y+thick/2,z) for x,z in coords]
 f=[tuple(range(n-1,-1,-1)),tuple(range(n,n*2))]+[(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)]
 me=bpy.data.meshes.new(name);me.from_pydata(v,[],f);me.update();ob=bpy.data.objects.new(name,me);col.objects.link(ob);return finish(ob,name,mi,bev)
def path(name,points,r=.018,mi=1,sides=6):
 # Tubular filigree follows intentional traced architectural paths.
 cu=bpy.data.curves.new(name,'CURVE');cu.dimensions='3D';cu.resolution_u=1;cu.bevel_depth=r;cu.use_fill_caps=True;cu.bevel_resolution=1;cu.resolution_u=1
 sp=cu.splines.new('POLY');sp.points.add(len(points)-1)
 for p,co in zip(sp.points,points):p.co=(*co,1)
 ob=bpy.data.objects.new(name,cu);col.objects.link(ob);bpy.context.view_layer.objects.active=ob;ob.select_set(True);bpy.ops.object.convert(target='MESH');ob.select_set(False);return finish(ob,name,mi)
def cyl(name,z,rad,depth,mi=1,verts=12):
 bpy.ops.mesh.primitive_cylinder_add(vertices=verts,radius=rad,depth=depth,location=(0,0,z));return finish(bpy.context.object,name,mi,.014)
def gem(name,x,z,w,h,mi=4,y=-.1):
 # Faceted, double-pyramid crystal with strong diamond silhouette.
 vs=[(x-w,y,z),(x,y,z+h),(x+w,y,z),(x,y,z-h),(x,y-.14,z),(x,y+.1,z)]
 fs=[(0,1,4),(1,2,4),(2,3,4),(3,0,4),(1,0,5),(2,1,5),(3,2,5),(0,3,5)]
 me=bpy.data.meshes.new(name);me.from_pydata(vs,[],fs);ob=bpy.data.objects.new(name,me);col.objects.link(ob);return finish(ob,name,mi)
# Each long rail is a longitudinal ridged, double-edge blade; central seam is open around crystal.
def blade(s):
 stations=[(1.00,.095,.28),(1.40,.09,.47),(1.85,.065,.42),(4.95,.04,.32),(5.75,.03,.23),(6.60,0,.0)]
 v=[]
 for z,inner,outer in stations:
  ridge=inner+(outer-inner)*.53
  blade_depth=.105*min(1,outer/.23)
  v.extend([(s*inner,0,z),(s*ridge,-blade_depth,z),(s*outer,0,z),(s*ridge,blade_depth,z)])
 f=[]
 for j in range(len(stations)-1):
  for a in range(4):f.append((j*4+a,j*4+(a+1)%4,(j+1)*4+(a+1)%4,(j+1)*4+a))
 f.extend([(3,2,1,0),(20,21,22,23)])
 me=bpy.data.meshes.new('Forged rail');me.from_pydata(v,[],f);me.update();ob=bpy.data.objects.new('Blade rail '+str(s),me);col.objects.link(ob);finish(ob,ob.name,0,.006)
 # Gilded inlaid channels descend toward the celestial collar.
 for sy in [-1,1]:
  path('Gilt blade channel',[(s*.18,sy*.087,1.5),(s*.23,sy*.107,2.02),(s*.195,sy*.106,4.95),(s*.135,sy*.093,5.7),(s*.055,sy*.035,6.23)],.011,1)
 for z in [2.1,2.68,3.26,3.84,4.42,5.0]:
  xx=.24-(z-2.1)*.025
  for sy in [-1,1]:
   path('Constellation chevron',[(s*(xx-.048),sy*.109,z+.07),(s*xx,sy*.118,z),(s*(xx+.048),sy*.109,z+.07)],.008,6)
blade(1);blade(-1)
poly('Suspended aether spine',[(-.066,1.1),(-.053,4.8),(0,6.5),(.053,4.8),(.066,1.1)],.10,7,.005)
# Six small connective bindings are structural, not arbitrary ornaments.
for z in [1.75,2.9,4.05,5.2]:
 poly('Core suspension clasp',[(-.13,z-.033),(.13,z-.033),(.13,z+.033),(-.13,z+.033)],.09,1,.005)
# Sculptural, interrupted circular guard with crisp faceted architectural arcs.
def arc(name,start,end,R,width,mi,y=0,depth=.16):
 coords=[(R*cos(t),.65+R*sin(t)) for t in [start+(end-start)*i/40 for i in range(41)]]
 coords+= [((R-width)*cos(t),.65+(R-width)*sin(t)) for t in [end-(end-start)*i/40 for i in range(41)]]
 return poly(name,coords,depth,mi,.012,y)
for a,b in [(32*pi/180,148*pi/180),(163*pi/180,377*pi/180)]:
 arc('Broken halo | ivory body',a,b,.84,.15,2)
 for sy in [-1,1]:
  for rr in [.715,.817]:path('Halo gilded rim',[(rr*cos(a+(b-a)*i/60),sy*.097,.65+rr*sin(a+(b-a)*i/60)) for i in range(61)],.014,1)
# Radiant swept wings sit behind halo, long thin points echo blade tip.
for s in [-1,1]:
 poly('Swept seraph quillon',[(s*.19,.55),(s*.48,.70),(s*.95,.60),(s*1.61,.97),(s*1.43,.57),(s*.94,.28),(s*.43,.34)],.22,0,.022,y=.045)
 poly('Ivory quillon feather',[(s*.55,.55),(s*.96,.48),(s*1.42,.76),(s*1.23,.48),(s*.92,.35)],.04,2,.009,y=-.082)
 for sy in [-1,1]:
  path('Quillon gold tracing',[(s*.24,sy*.15,.55),(s*.53,sy*.15,.62),(s*.97,sy*.14,.52),(s*1.49,sy*.08,.87)],.024,1)
  path('Quillon feather channel',[(s*.68,sy*.14,.41),(s*.97,sy*.14,.36),(s*1.31,sy*.12,.57)],.012,1)
 gem('Guard satellite',s*.96,.46,.075,.11,4,-.14)
# Cathedral-like central collar with layered geometry and azure focus.
poly('Guard central cathedral',[(-.23,.18),(-.34,.53),(-.25,.99),(0,1.28),(.25,.99),(.34,.53),(.23,.18)],.26,1,.016)
poly('Guard inset enamel',[(-.15,.31),(-.23,.56),(-.16,.91),(0,1.10),(.16,.91),(.23,.56),(.15,.31)],.036,5,.01,y=-.152)
gem('Genesis heart',0,.71,.135,.3,4,-.184)
for sy in [-1,1]:
 path('Collar nested arch',[(-.19,sy*.185,.42),(-.19,sy*.185,.88),(0,sy*.185,1.16),(.19,sy*.185,.88),(.19,sy*.185,.42)],.018,6)
# Hand-length grip: subtle taper, actual helical wrap with alternating seams.
cyl('Grip upper ferrule',.11,.203,.20,1)
cyl('Octagonal leather grip',-.65,.151,1.32,3,12)
for i in range(12):
 z=-1.24+i*.108
 pts=[]
 for j in range(49):
  t=j/48*2*pi;pts.append((.158*cos(t),.158*sin(t),z+j/48*.10))
 path('Raised leather spiral',pts,.022,3)
for z in [-1.35,-1.26,-.02]:cyl('Engraved grip ferrule',z,.185,.065,1)
# Front and back gold grip splines, distinct diamond insets.
for sy in [-1,1]:
 path('Grip spine inlay',[(0,sy*.173,-1.19),(0,sy*.173,-.10)],.014,1)
 for z in [-.29,-.66,-1.02]:gem('Grip lozenge',0,z,.044,.068,6,sy*.179)
# Open aureole pommel with a floating elongated teardrop crystal.
poly('Pommel crown',[(-.18,-1.34),(-.29,-1.54),(-.19,-1.67),(0,-1.49),(.19,-1.67),(.29,-1.54),(.18,-1.34)],.18,1,.017)
for s in [-1,1]:
 poly('Pommel carved cage',[(s*.11,-1.50),(s*.28,-1.66),(s*.25,-1.90),(0,-2.19),(s*.13,-1.86),(s*.16,-1.70)],.15,0,.012)
 path('Pommel gilt rim',[(s*.13,-.09,-1.51),(s*.26,-.09,-1.68),(s*.23,-.09,-1.87),(0,-.09,-2.17)],.014,1)
gem('Genesis seed crystal',0,-1.80,.115,.24,4,-.005)
gem('Pommel star tip',0,-2.18,.065,.095,6,0)
# UV atlas per material. Triplanar projection yields non-overlapping swatch families.
for ob in parts:
 me=ob.data
 uv=me.uv_layers.new(name='GenesisAtlas')
 mi=palette.index(next(p for p in palette if p[0]==me.materials[0].name))
 ux=(mi%4)/4;uy=(mi//4)/2
 for face in me.polygons:
  normalvec=face.normal;axis=max(range(3),key=lambda i:abs(normalvec[i]));axes=[i for i in range(3) if i!=axis]
  for li in face.loop_indices:
   co=me.vertices[me.loops[li].vertex_index].co
   a=(co[axes[0]]*.63)%1;b=(co[axes[1]]*.41)%1
   uv.data[li].uv=(ux+.015+a*.22,uy+.015+b*.47)
# Clean each closed component independently, preserving contact boundaries.
import bmesh
for ob in parts:
 for layer in list(ob.data.uv_layers):
  if layer.name != 'GenesisAtlas':ob.data.uv_layers.remove(layer)
 ob.data.uv_layers.active=ob.data.uv_layers.get('GenesisAtlas')
 bm=bmesh.new();bm.from_mesh(ob.data)
 bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=.000001)
 bmesh.ops.dissolve_degenerate(bm,edges=list(bm.edges),dist=.000001)
 bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(ob.data);bm.free();ob.data.update()
# Bake object transforms, set handle-centered origin: Y front/back, Z blade-up.
bpy.ops.object.select_all(action='DESELECT')
for ob in parts: ob.select_set(True)
bpy.context.view_layer.objects.active=parts[0]
bpy.ops.object.join();weapon=bpy.context.object;weapon.name='Genesis_Sword';weapon.data.name='Genesis_Sword_Mesh'
scene.cursor.location=(0,0,-.66);bpy.ops.object.origin_set(type='ORIGIN_CURSOR');weapon.location=(0,0,0)
bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
# Consolidate portable shader: all metals, enamel and leather are encoded in one atlas.
weapon.name='Handle'
master=mats[0].copy();master.name='Genesis_PBR_Atlas'
weapon.data.materials.clear();weapon.data.materials.append(master)
for face in weapon.data.polygons:face.material_index=0
import bmesh
bm=bmesh.new();bm.from_mesh(weapon.data)
bmesh.ops.dissolve_degenerate(bm,edges=list(bm.edges),dist=.000001)
bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(weapon.data);bm.free();weapon.data.update()
# Mesh custom metadata included in editable source.
weapon['Design']='GENESIS • Aether-forged celestial relic';weapon['Pivot']='Grip center; +Z toward blade, front -Y';weapon['Roblox']='One MeshPart. Import scale as needed; use supplied PBR maps in SurfaceAppearance.'
weapon['Texture']='UV0: shared 512px atlas. Cyan is PBR color; source emission is optional.'
scene.unit_settings.system='NONE';scene.unit_settings.scale_length=1
# Exports: only actual sword selected.
bpy.ops.export_scene.fbx(filepath=ROOT+'/Genesis_Sword.fbx',use_selection=True,add_leaf_bones=False,apply_unit_scale=True,axis_forward='Z',axis_up='Y',apply_scale_options='FBX_SCALE_UNITS',bake_anim=False,path_mode='COPY',embed_textures=True,object_types={'MESH'},use_mesh_modifiers=True)
bpy.ops.export_scene.gltf(filepath=ROOT+'/Genesis_Sword.glb',export_format='GLB',use_selection=True,export_yup=True,export_texcoords=True,export_normals=True,export_materials='EXPORT')
bpy.ops.wm.obj_export(filepath=ROOT+'/Genesis_Sword.obj',export_selected_objects=True,export_materials=True,forward_axis='NEGATIVE_Z',up_axis='Y',path_mode='COPY')
# Readable companion maps for Roblox SurfaceAppearance.
for channel,name in [(1,'Genesis_Roughness.png'),(2,'Genesis_Metalness.png')]:
 im=bpy.data.images.new(name,width=N,height=N,alpha=True);ps=[]
 for i in range(N*N):v=opix[i*4+channel];ps.extend([v,v,v,1])
 im.colorspace_settings.name='Non-Color';im.pixels=ps;im.filepath_raw=ROOT+'/'+name;im.file_format='PNG';im.save();im.pack()
base.pack();orm.pack();normal.pack()
# Museum-style lighting and background, never part of the export.
def move_studio(ob):
 for c in list(ob.users_collection):c.objects.unlink(ob)
 studio.objects.link(ob)
def area(name,loc,energy,color,size,target=(0,0,2.7)):
 bpy.ops.object.light_add(type='AREA',location=loc);ob=bpy.context.object;ob.name=name;move_studio(ob);ob.data.energy=energy;ob.data.color=color;ob.data.shape='DISK';ob.data.size=size;ob.rotation_euler=(Vector(target)-ob.location).to_track_quat('-Z','Y').to_euler()
area('Key | warm softbox',(-4,-5,7),1000,(1,.87,.66),5)
area('Edge | cold strip',(3,1,6),1350,(.29,.64,1),4)
area('Fill | blue silver',(3,-5,2),650,(.52,.76,1),4)
area('Pommel kicker',(-2,-2,-1),180,(.4,.77,1),2)
world=bpy.data.worlds.new('Midnight gallery') if not bpy.data.worlds else bpy.data.worlds[0];scene.world=world;world.use_nodes=True;world.node_tree.nodes['Background'].inputs[0].default_value=(.017,.024,.041,1);world.node_tree.nodes['Background'].inputs[1].default_value=.4
bpy.ops.object.camera_add(location=(8,-24,10));cam=bpy.context.object;cam.name='CAMERA | Hero';move_studio(cam);scene.camera=cam
cam.data.type='ORTHO';cam.data.ortho_scale=10.4
cam.rotation_euler=(Vector((0,0,2.88))-cam.location).to_track_quat('-Z','Y').to_euler()
scene.render.engine='CYCLES';scene.cycles.samples=160;scene.cycles.use_denoising=False
scene.render.resolution_x=1400;scene.render.resolution_y=1800;scene.render.resolution_percentage=100
scene.view_settings.view_transform='AgX'
scene.render.image_settings.file_format='PNG';scene.render.film_transparent=False
# Compositor restrained glow only affects preview, with no promised Roblox bloom.
scene.use_nodes=True;nodes=scene.node_tree.nodes;nodes.clear();rl=nodes.new('CompositorNodeRLayers');g=nodes.new('CompositorNodeGlare');g.glare_type='FOG_GLOW';g.quality='HIGH';g.threshold=1.7;g.mix=-.92;o=nodes.new('CompositorNodeComposite');scene.node_tree.links.new(rl.outputs['Image'],g.inputs[0]);scene.node_tree.links.new(g.outputs[0],o.inputs[0])
bpy.ops.object.select_all(action='DESELECT');weapon.select_set(True);bpy.context.view_layer.objects.active=weapon
# Home view aligned to camera and saved source with image textures packed.
for screen in bpy.data.screens:
 for ar in screen.areas:
  if ar.type=='VIEW_3D':ar.spaces.active.region_3d.view_perspective='CAMERA'
scene.render.filepath=ROOT+'/Genesis_Hero.png'
bpy.ops.wm.save_as_mainfile(filepath=ROOT+'/Genesis_Sword.blend')
tris=sum(len(p.vertices)-2 for p in weapon.data.polygons)
with open(ROOT+'/model_stats.txt','w') as f:f.write(f'Vertices: {len(weapon.data.vertices)}\nPolygons: {len(weapon.data.polygons)}\nTriangles: {tris}\nDimensions: {tuple(weapon.dimensions)}\nMaterials: {len(weapon.data.materials)}\n')
bpy.ops.render.render(write_still=True)
cam.location=(3.8,-14,4.9);target=Vector((0,0,1.09));cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.ortho_scale=4.9
scene.render.resolution_x=1600;scene.render.resolution_y=1400;scene.render.filepath=ROOT+'/Genesis_Detail.png';bpy.ops.render.render(write_still=True)
print('GENESIS_BUILD_COMPLETE')
