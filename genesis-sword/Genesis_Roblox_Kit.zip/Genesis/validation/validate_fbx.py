"""Blender background FBX roundtrip audit. Usage: blender -b --python this.py -- input.fbx report.json"""
import bpy, bmesh, json, sys, math, os
from mathutils import Vector
args = sys.argv[sys.argv.index('--')+1:]
source, report_path = args
bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.ops.import_scene.fbx(filepath=os.path.abspath(source))
report = {'file':os.path.basename(source), 'blender_version':bpy.app.version_string, 'test':'FBX re-import in Blender; not a Roblox Studio import or gameplay test', 'meshes':[]}
all_coords=[]
for ob in sorted(bpy.context.scene.objects,key=lambda o:o.name):
 if ob.type != 'MESH': continue
 dg=bpy.context.evaluated_depsgraph_get(); eo=ob.evaluated_get(dg); me=eo.to_mesh(); me.calc_loop_triangles()
 bm=bmesh.new(); bm.from_mesh(me)
 coords=[ob.matrix_world @ v.co for v in me.vertices]; all_coords.extend(coords)
 row={'name':ob.name,'vertices':len(me.vertices),'triangles':len(me.loop_triangles),'boundary_edges':sum(e.is_boundary for e in bm.edges),'non_manifold_edges':sum(not e.is_manifold for e in bm.edges),'degenerate_faces':sum(p.area < 1e-12 for p in me.polygons),'loose_vertices':sum(not v.link_faces for v in bm.verts),'signed_local_volume':bm.calc_volume(signed=True),'materials':[m.name if m else None for m in me.materials],'uv_layers':len(me.uv_layers),'uv_layer_names':[u.name for u in me.uv_layers],'uv_bounds':{u.name:{'min':[min(x.uv[i] for x in u.data) for i in range(2)],'max':[max(x.uv[i] for x in u.data) for i in range(2)]} for u in me.uv_layers},'world_dimensions':[max(p[i] for p in coords)-min(p[i] for p in coords) for i in range(3)],'origin_world':list(ob.matrix_world.translation),'finite_coordinates':all(math.isfinite(c) for p in coords for c in p)}
 row['passes_basic_geometry_checks']=row['triangles']<=20000 and row['non_manifold_edges']==0 and row['degenerate_faces']==0 and row['loose_vertices']==0 and row['finite_coordinates'] and abs(row['signed_local_volume'])>1e-10 and row['uv_layers']<=1 and len(row['materials'])<=1
 report['meshes'].append(row); bm.free(); eo.to_mesh_clear()
report['mesh_count']=len(report['meshes']); report['total_triangles']=sum(r['triangles'] for r in report['meshes']); report['passes_basic_geometry_checks']=bool(report['meshes']) and all(r['passes_basic_geometry_checks'] for r in report['meshes'])
if all_coords: report['world_bounds']={'min':[min(p[i] for p in all_coords) for i in range(3)],'max':[max(p[i] for p in all_coords) for i in range(3)],'dimensions':[max(p[i] for p in all_coords)-min(p[i] for p in all_coords) for i in range(3)]}
with open(report_path,'w') as f: json.dump(report,f,indent=2)
print(json.dumps(report,indent=2))
