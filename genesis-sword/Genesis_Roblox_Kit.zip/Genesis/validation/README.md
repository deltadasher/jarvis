# Local validation

`fbx_roundtrip.json` is produced by importing the delivered FBX into a fresh Blender scene with the bundled `validate_fbx.py` script. The JSON reports geometry checks and source-unit bounds. Blender's Z-up roundtrip dimensions are reported, not Roblox's Y-up axes.

Run again after editing with:

    blender -b --python validation/validate_fbx.py -- Genesis_Sword.fbx validation/fbx_roundtrip.json

A pass checks closed edge topology, nondegenerate faces, finite coordinates, no loose vertices, nonzero total enclosed volume, no more than one UV set/material, and the 20,000-triangle ceiling. It does not check every possible self-intersection or visual overlap among decorative shells. It does not prove Roblox Studio import, moderation, permissions or gameplay compatibility.

The optional neutral normal map does not add sculpted detail. Geometric facets, bevels and the color/PBR maps create the delivered appearance.
