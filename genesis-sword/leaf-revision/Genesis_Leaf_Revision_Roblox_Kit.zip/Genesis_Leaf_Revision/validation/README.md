# Local validation

Independent Blender 4.3.2 re-imports of the final FBX, OBJ and GLB pass the intended composite-prop geometry checks. Each has one Handle mesh, 11,162 triangles, one material and one bounded UV set. All exports exclude cameras/lights/presentation objects. Export hashes are recorded in export_roundtrip.json; texture checks and file hashes are in texture_and_export_audit.json.

FBX/OBJ have zero raw non-manifold or boundary edges, zero degenerate triangles, finite normalized normals and consistently oriented closed components. GLB seam splits are expected; its raw non-manifold count does not imply visible holes. Global spatial welding intentionally changes topology and exposes one shared edge in overlapping pommel detail shells. This is a composite game prop, not a boolean-unioned printable solid.

Reproduce: blender -b --python validation/audit_exports.py -- . validation/export_roundtrip.json
Package audit: python validation/audit_package.py . package_audit.json (requires Pillow). Keep a zip's hash/CRC report outside that same zip to avoid self-referential hashes.

Not tested in Roblox Studio. No claim is made regarding moderation, account/group asset permission, Studio-scale interpretation, Tool.Grip, rig attachment, collision gameplay, damage, animation or networking. See README_IMPORT.md for assembly steps and the current official 20,000-triangle-per-mesh reference.
