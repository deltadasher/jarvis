from PIL import Image,ImageChops
from pathlib import Path
import json,hashlib,zipfile,sys,struct
root=Path(sys.argv[1]);report={};textures={}
for p in sorted(root.glob('Genesis_*.png')):
 if any(k in p.name for k in ['BaseColor','Metalness','Roughness','Normal','ORM']):
  im=Image.open(p);im.load();textures[p.name]={'size':im.size,'mode':im.mode,'extrema':im.getextrema()}
report['textures']=textures
orm=Image.open(root/'Genesis_ORM.png').convert('RGB');metal=Image.open(root/'Genesis_Metalness.png').convert('RGB');rough=Image.open(root/'Genesis_Roughness.png').convert('RGB')
report['orm_metalness_matches']=all(ImageChops.difference(orm.getchannel('B'),c).getbbox() is None for c in metal.split())
report['orm_roughness_matches']=all(ImageChops.difference(orm.getchannel('G'),c).getbbox() is None for c in rough.split())
b=(root/'Genesis_Sword.glb').read_bytes();magic,version,size=struct.unpack('<4sII',b[:12]);n,t=struct.unpack('<II',b[12:20]);gltf=json.loads(b[20:20+n]);report['glb']={'magic':magic.decode(),'version':version,'declared_size_matches':size==len(b),'meshes':len(gltf.get('meshes',[])),'materials':gltf.get('materials',[]),'images':gltf.get('images',[]),'cameras':gltf.get('cameras',[]),'animations':gltf.get('animations',[])}
report['files']={p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(root.iterdir()) if p.is_file() and p.suffix in ['.fbx','.obj','.mtl','.glb','.blend','.png','.zip']}
report['zips']=[]
for p in root.glob('*.zip'):
 with zipfile.ZipFile(p) as z:
  report['zips'].append({'file':p.name,'crc_failure':z.testzip(),'contents':z.namelist(),'unsafe_paths':[x for x in z.namelist() if x.startswith('/') or '..' in Path(x).parts],'disk_mismatches':[x for x in z.namelist() if not x.endswith('/') and (root/x).is_file() and z.read(x)!=(root/x).read_bytes()]})
json.dump(report,open(sys.argv[2],'w'),indent=2)
print(json.dumps(report,indent=2))
